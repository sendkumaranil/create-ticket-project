"""
MCP Ticket System - Main Entry Point
=====================================
Run this to start the full end-to-end demo.

Architecture:
┌─────────────────────────────────────────────────────────┐
│                    Chat Window (Python CLI)               │
│                        client/chat_window.py             │
└──────────────────────┬──────────────────────────────────┘
                       │ user message
                       ▼
┌─────────────────────────────────────────────────────────┐
│                  SupervisorAgent                         │
│           • Classifies intent (NLP/LLM)                  │
│           • Delegates to CreateTicketAgent               │
└──────────────────────┬──────────────────────────────────┘
                       │ delegate
                       ▼
┌─────────────────────────────────────────────────────────┐
│               CreateTicketAgent                          │
│           • Calls MCP tool: render_ticket_form           │
│           • Returns UI schema to chat window             │
│           • User fills form                              │
│           • Calls MCP tool: submit_ticket                │
└──────────────────────┬──────────────────────────────────┘
                       │ JSON-RPC over TCP
                       ▼
┌─────────────────────────────────────────────────────────┐
│                  MCP Server (port 9000)                  │
│           • Handles tool calls                           │
│           • render_ticket_form → returns UI schema       │
│           • submit_ticket → calls backend API            │
└──────────────────────┬──────────────────────────────────┘
                       │ HTTP POST
                       ▼
┌─────────────────────────────────────────────────────────┐
│             Mock Ticket API (port 8080)                  │
│           • POST /api/tickets → creates ticket           │
│           • Returns ticket_id + details                  │
└─────────────────────────────────────────────────────────┘
"""

import sys
import os

# Make sure all submodules are importable
sys.path.insert(0, os.path.dirname(__file__))

from client.chat_window import run_chat

if __name__ == "__main__":
    run_chat()
