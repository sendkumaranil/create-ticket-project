from setuptools import setup, find_packages

setup(
    name="mcp-ticket-system",
    version="1.0.0",
    description="End-to-end MCP (Model Context Protocol) Ticket System with AI Agents",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Anil Kumar",
    author_email="sendkumaranil@gmail.com",
    url="https://github.com/sendkumaranil/mcp-ticket-system",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "Flask>=3.0.0",
    ],
    entry_points={
        "console_scripts": [
            "mcp-ticket=main:run_chat",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
    ],
)
