"""
MCP Client Chat Window
========================
Python terminal-based chat window that:
  1. Accepts user messages
  2. Sends to SupervisorAgent
  3. Renders MCP UI (forms) from JSON schema in terminal
  4. Collects user input for the form
  5. Submits via MCP tool
  6. Displays confirmation

This is the "chat window" — in production this would be a web UI or
Slack bot that renders actual HTML forms. Here we render in terminal with
ANSI colors and structured prompts.
"""

import sys
import os
import json
import time
import threading

sys.path.insert(0, os.path.dirname(__file__))

from mock_api.ticket_api import run as run_api, app as flask_app
from mcp_server.server import start_server_thread
from agents.agents import MCPClient, SupervisorAgent


# ─────────────────────────────────────────────
# Terminal Colors & UI Helpers
# ─────────────────────────────────────────────

class Colors:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    CYAN    = "\033[96m"
    BLUE    = "\033[94m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    RED     = "\033[91m"
    MAGENTA = "\033[95m"
    WHITE   = "\033[97m"
    BG_DARK = "\033[40m"
    GRAY    = "\033[90m"

def print_banner():
    print(f"\n{Colors.CYAN}{'═'*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}  🎫  MCP Ticket System — Chat Window{Colors.RESET}")
    print(f"{Colors.GRAY}  Architecture: Chat → SupervisorAgent → CreateTicketAgent")
    print(f"              → MCP Tool → MCP Server → Ticket API{Colors.RESET}")
    print(f"{Colors.CYAN}{'═'*60}{Colors.RESET}\n")

def print_message(role: str, text: str):
    if role == "user":
        print(f"\n{Colors.BOLD}{Colors.BLUE}You:{Colors.RESET} {text}")
    elif role == "assistant":
        print(f"\n{Colors.BOLD}{Colors.GREEN}Assistant:{Colors.RESET} {text}")
    elif role == "system":
        print(f"\n{Colors.DIM}{Colors.GRAY}[System] {text}{Colors.RESET}")
    elif role == "agent":
        print(f"\n{Colors.BOLD}{Colors.MAGENTA}Agent:{Colors.RESET} {Colors.DIM}{text}{Colors.RESET}")
    elif role == "success":
        print(f"\n{Colors.BOLD}{Colors.GREEN}✅ {text}{Colors.RESET}")
    elif role == "error":
        print(f"\n{Colors.BOLD}{Colors.RED}❌ {text}{Colors.RESET}")

def divider(char="─", color=Colors.GRAY):
    print(f"{color}{char*60}{Colors.RESET}")


# ─────────────────────────────────────────────
# Terminal Form Renderer
# ─────────────────────────────────────────────

PRIORITY_COLORS = {
    "low":      Colors.GREEN,
    "medium":   Colors.YELLOW,
    "high":     Colors.RED,
    "critical": Colors.MAGENTA,
}

CATEGORY_LABELS = {
    "api_access":      "🔑 API Access Request",
    "bug":             "🐛 Bug Report",
    "feature_request": "✨ Feature Request",
    "support":         "💬 General Support",
    "general":         "📋 Other",
}

def render_form_terminal(ui_schema: dict) -> dict:
    """
    Renders the MCP UI schema as an interactive terminal form.
    Returns the collected form data dict.
    """
    content = ui_schema.get("content", ui_schema)

    print(f"\n{Colors.BOLD}{Colors.CYAN}{'╔' + '═'*58 + '╗'}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}║  {content['title']:<55} ║{Colors.RESET}")
    print(f"{Colors.CYAN}║  {Colors.DIM}{content['subtitle']:<55}{Colors.CYAN}  ║{Colors.RESET}")
    print(f"{Colors.CYAN}{'╚' + '═'*58 + '╝'}{Colors.RESET}\n")

    collected = {}

    for field in content["fields"]:
        fid       = field["id"]
        label     = field["label"]
        ftype     = field["type"]
        default   = field.get("value", "")
        required  = field.get("required", False)
        req_mark  = f"{Colors.RED}*{Colors.RESET}" if required else ""

        if ftype == "text" or ftype == "email":
            prompt_str = (
                f"{Colors.BOLD}{label}{Colors.RESET}{req_mark}"
                + (f" [{Colors.DIM}{default}{Colors.RESET}]" if default else "")
                + f"\n  {Colors.GRAY}→ {Colors.RESET}"
            )
            val = input(prompt_str).strip()
            if not val and default:
                val = default
            while required and not val:
                print(f"  {Colors.RED}This field is required.{Colors.RESET}")
                val = input(f"  {Colors.GRAY}→ {Colors.RESET}").strip()
            collected[fid] = val
            print()

        elif ftype == "textarea":
            print(f"{Colors.BOLD}{label}{Colors.RESET}{req_mark}")
            if default:
                print(f"  {Colors.DIM}Current: {default[:100]}...{Colors.RESET}")
                change = input(f"  Press Enter to keep, or type new description:\n  {Colors.GRAY}→ {Colors.RESET}").strip()
                collected[fid] = change if change else default
            else:
                val = input(f"  {Colors.GRAY}→ {Colors.RESET}").strip()
                while required and not val:
                    print(f"  {Colors.RED}This field is required.{Colors.RESET}")
                    val = input(f"  {Colors.GRAY}→ {Colors.RESET}").strip()
                collected[fid] = val
            print()

        elif ftype == "select":
            print(f"{Colors.BOLD}{label}{Colors.RESET}{req_mark}")
            options = field["options"]
            for i, opt in enumerate(options, 1):
                marker = "●" if opt["value"] == default else "○"
                color  = Colors.CYAN if opt["value"] == default else Colors.GRAY
                print(f"  {color}{marker} {i}. {opt['label']}{Colors.RESET}")
            choice = input(
                f"  Enter number (default={[o['value'] for o in options].index(default)+1 if default in [o['value'] for o in options] else 1}): "
            ).strip()
            if choice.isdigit() and 1 <= int(choice) <= len(options):
                collected[fid] = options[int(choice)-1]["value"]
            else:
                collected[fid] = default or options[0]["value"]
            chosen_label = next(o["label"] for o in options if o["value"] == collected[fid])
            print(f"  {Colors.GREEN}✓ Selected: {chosen_label}{Colors.RESET}\n")

        elif ftype == "radio_group":
            print(f"{Colors.BOLD}{label}{Colors.RESET}{req_mark}")
            options = field["options"]
            for i, opt in enumerate(options, 1):
                is_default = opt["value"] == default
                pcol = PRIORITY_COLORS.get(opt["value"], Colors.WHITE)
                marker = "●" if is_default else "○"
                print(f"  {pcol}{marker} {i}. {opt['label']}{Colors.RESET}")
            choice = input(
                f"  Enter number (default={[o['value'] for o in options].index(default)+1 if default in [o['value'] for o in options] else 2}): "
            ).strip()
            if choice.isdigit() and 1 <= int(choice) <= len(options):
                collected[fid] = options[int(choice)-1]["value"]
            else:
                collected[fid] = default or options[1]["value"]
            pcol = PRIORITY_COLORS.get(collected[fid], Colors.WHITE)
            print(f"  {Colors.GREEN}✓ Priority: {pcol}{collected[fid].upper()}{Colors.RESET}\n")

        elif ftype == "tags":
            print(f"{Colors.BOLD}{label}{Colors.RESET}")
            existing = list(default) if default else []
            if existing:
                print(f"  {Colors.DIM}Suggested tags: {', '.join(existing)}{Colors.RESET}")
            extra = input(
                f"  Add more tags (comma-separated, or Enter to keep):\n  {Colors.GRAY}→ {Colors.RESET}"
            ).strip()
            if extra:
                new_tags = [t.strip() for t in extra.split(",") if t.strip()]
                existing = list(set(existing + new_tags))
            collected[fid] = existing
            if existing:
                print(f"  {Colors.GREEN}✓ Tags: {', '.join(existing)}{Colors.RESET}")
            print()

    return collected


def show_ticket_summary(form_data: dict):
    """Display a pre-submission summary."""
    print(f"\n{Colors.BOLD}{Colors.YELLOW}{'─'*60}")
    print("  📋 Ticket Summary — Review Before Submitting")
    print(f"{'─'*60}{Colors.RESET}")

    pcol = PRIORITY_COLORS.get(form_data.get("priority", ""), Colors.WHITE)
    cat_label = CATEGORY_LABELS.get(form_data.get("category", ""), form_data.get("category", ""))

    fields_to_show = [
        ("Title",       form_data.get("title",           "")),
        ("Category",    cat_label),
        ("Priority",    f"{pcol}{form_data.get('priority','').upper()}{Colors.RESET}"),
        ("Email",       form_data.get("requester_email", "")),
        ("Tags",        ", ".join(form_data.get("tags",  []))),
    ]
    for k, v in fields_to_show:
        print(f"  {Colors.BOLD}{k:<12}{Colors.RESET} {v}")

    desc = form_data.get("description", "")
    if len(desc) > 80:
        desc = desc[:77] + "..."
    print(f"  {Colors.BOLD}{'Description':<12}{Colors.RESET} {Colors.DIM}{desc}{Colors.RESET}")
    print(f"{Colors.YELLOW}{'─'*60}{Colors.RESET}")


def show_ticket_confirmation(ticket_id: str, ticket: dict):
    """Display ticket creation confirmation."""
    print(f"\n{Colors.BOLD}{Colors.GREEN}{'╔' + '═'*58 + '╗'}")
    print(f"║  🎉 Ticket Created Successfully!{'':>25}║")
    print(f"{'╚' + '═'*58 + '╝'}{Colors.RESET}")

    pcol = PRIORITY_COLORS.get(ticket.get("priority", ""), Colors.WHITE)
    rows = [
        ("Ticket ID",  f"{Colors.BOLD}{Colors.CYAN}{ticket_id}{Colors.RESET}"),
        ("Title",      ticket.get("title", "")),
        ("Status",     f"{Colors.GREEN}● Open{Colors.RESET}"),
        ("Category",   CATEGORY_LABELS.get(ticket.get("category",""), ticket.get("category",""))),
        ("Priority",   f"{pcol}{ticket.get('priority','').upper()}{Colors.RESET}"),
        ("Email",      ticket.get("requester_email", "")),
        ("Created",    ticket.get("created_at","")[:19]),
    ]
    for k, v in rows:
        print(f"  {Colors.BOLD}{k:<12}{Colors.RESET} {v}")

    print(f"\n  {Colors.DIM}You will receive email updates as your ticket progresses.{Colors.RESET}")
    print(f"{Colors.GREEN}{'═'*60}{Colors.RESET}")


# ─────────────────────────────────────────────
# Main Chat Loop
# ─────────────────────────────────────────────

def start_infrastructure():
    """Start Mock API and MCP server in background threads."""
    print_message("system", "Starting Mock Ticket API on port 8080...")
    api_thread = threading.Thread(
        target=lambda: flask_app.run(port=8080, debug=False, use_reloader=False),
        daemon=True
    )
    api_thread.start()
    time.sleep(0.8)
    print_message("system", "✓ Ticket API ready")

    print_message("system", "Starting MCP Server on port 9000...")
    mcp_server = start_server_thread()
    time.sleep(0.5)
    print_message("system", "✓ MCP Server ready")

    return mcp_server


def run_chat():
    print_banner()

    # Start services
    start_infrastructure()

    # Connect MCP client
    print_message("system", "Connecting MCP client to server...")
    mcp_client = MCPClient()
    mcp_client.connect()
    print_message("system", "✓ MCP client connected\n")

    # List available tools
    tools = mcp_client.list_tools()
    print_message("system", f"MCP tools available: {[t['name'] for t in tools]}\n")

    # Create supervisor agent
    supervisor = SupervisorAgent(mcp_client)

    divider("═", Colors.CYAN)
    print_message("assistant",
        "Hello! I'm your AI assistant. I can help you raise support tickets, "
        "check ticket status, or answer questions. How can I help you today?"
    )
    print(f"\n{Colors.DIM}  Try: 'I want to onboard a new API and sign up form so I can get API access'{Colors.RESET}")
    print(f"{Colors.DIM}  Type 'quit' to exit{Colors.RESET}\n")

    while True:
        divider()
        try:
            user_input = input(f"{Colors.BOLD}{Colors.BLUE}You: {Colors.RESET}").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input.lower() in ("quit", "exit", "bye"):
            print_message("assistant", "Goodbye! Your tickets are in good hands. 👋")
            break

        # ── Step 1: Supervisor classifies + delegates ──
        print_message("system", "Sending to SupervisorAgent...")
        response = supervisor.process(user_input)

        if response.action == "render_form":
            # ── Step 2: Render MCP UI form ──
            print_message("assistant",
                f"I've detected you want to {response.data.get('intent',{}).get('name','create a ticket').replace('_',' ')}. "
                f"I've pre-filled the form based on your request. "
                f"Please review and complete the details:"
            )
            ui_content = response.data.get("content", {})
            form_data = render_form_terminal(ui_content)

            # ── Step 3: Show summary + confirm ──
            show_ticket_summary(form_data)
            confirm = input(
                f"\n{Colors.BOLD}Submit this ticket? (yes/no): {Colors.RESET}"
            ).strip().lower()

            if confirm in ("yes", "y", ""):
                print_message("system", "Submitting ticket via MCP client → MCP tool → API...")

                # ── Step 4: MCP client invokes submit_ticket tool ──
                ticket_response = supervisor.ticket_agent.submit_ticket(form_data)

                if ticket_response.action == "ticket_created":
                    # ── Step 5: Show confirmation ──
                    show_ticket_confirmation(
                        ticket_response.data["ticket_id"],
                        ticket_response.data["ticket"]
                    )
                    print_message("assistant",
                        f"Your ticket has been submitted successfully! 🎉\n"
                        f"  Reference number: {Colors.BOLD}{Colors.CYAN}"
                        f"{ticket_response.data['ticket_id']}{Colors.RESET}\n"
                        f"  Our team will review your request and get back to you shortly.\n"
                        f"  Is there anything else I can help you with?"
                    )
                else:
                    print_message("error", ticket_response.message)
            else:
                print_message("assistant",
                    "Ticket submission cancelled. Feel free to start again whenever you're ready."
                )

        elif response.action == "reply":
            print_message("assistant", response.message)

        elif response.action == "error":
            print_message("error", response.message)

    mcp_client.disconnect()
    print_message("system", "Session ended.")


if __name__ == "__main__":
    run_chat()
