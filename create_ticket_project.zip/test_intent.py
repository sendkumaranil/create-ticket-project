"""
Unit tests for intent classification and MCP tool handlers.
Run with: python -m pytest tests/ -v
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import json
from agents.agents import classify_intent
from mcp_server.server import handle_tool_call, handle_mcp_message, MCP_TOOLS


class TestIntentClassification:
    def test_api_onboarding_intent(self):
        intent = classify_intent(
            "dear team I want to onboard new API and sign up form so that I can get access of API"
        )
        assert intent.name == "create_ticket"
        assert intent.confidence >= 0.9
        assert intent.slots["category"] == "api_access"
        assert "api" in intent.slots["tags"]
        assert "onboarding" in intent.slots["tags"]

    def test_bug_report_intent(self):
        intent = classify_intent("there is a bug and I need to raise a ticket to fix the login page error")
        assert intent.name == "create_ticket"
        assert intent.slots["category"] == "bug"

    def test_general_query_intent(self):
        intent = classify_intent("what is the weather today?")
        assert intent.name == "general_help"

    def test_critical_priority(self):
        intent = classify_intent("urgent blocking issue, please open a ticket asap to restore access")
        assert intent.name == "create_ticket"
        assert intent.slots["priority"] in ("critical", "high")

    def test_email_extraction(self):
        intent = classify_intent("I need API access, contact me at dev@company.com")
        assert intent.slots["requester_email"] == "dev@company.com"


class TestMCPTools:
    def test_tools_list(self):
        assert len(MCP_TOOLS) == 3
        names = [t["name"] for t in MCP_TOOLS]
        assert "render_ticket_form" in names
        assert "submit_ticket" in names
        assert "get_ticket_status" in names

    def test_render_form_returns_ui_schema(self):
        result = handle_tool_call("render_ticket_form", {
            "pre_filled": {"title": "Test", "category": "api_access", "priority": "high"}
        })
        assert result["type"] == "ui_render"
        ui = result["content"]
        assert ui["ui_type"] == "form"
        field_ids = [f["id"] for f in ui["fields"]]
        assert "title" in field_ids
        assert "category" in field_ids
        assert "priority" in field_ids
        assert "requester_email" in field_ids

    def test_submit_ticket_missing_fields(self):
        result = handle_tool_call("submit_ticket", {"title": "Incomplete"})
        assert result["type"] == "error"
        assert "Missing required fields" in result["message"]

    def test_unknown_tool(self):
        result = handle_tool_call("nonexistent_tool", {})
        assert result["type"] == "error"

    def test_mcp_initialize(self):
        response = handle_mcp_message({
            "jsonrpc": "2.0", "id": 1,
            "method": "initialize",
            "params": {"protocolVersion": "2024-11-05", "clientInfo": {}}
        })
        assert response["result"]["protocolVersion"] == "2024-11-05"
        assert "tools" in response["result"]["capabilities"]

    def test_mcp_tools_list(self):
        response = handle_mcp_message({
            "jsonrpc": "2.0", "id": 2,
            "method": "tools/list", "params": {}
        })
        assert len(response["result"]["tools"]) == 3

    def test_mcp_unknown_method(self):
        response = handle_mcp_message({
            "jsonrpc": "2.0", "id": 3,
            "method": "unknown/method", "params": {}
        })
        assert "error" in response


class TestMockAPI:
    def test_flask_app_importable(self):
        from mock_api.ticket_api import app, tickets_db
        assert app is not None
        assert isinstance(tickets_db, dict)

    def test_create_ticket_via_app(self):
        from mock_api.ticket_api import app
        client = app.test_client()
        resp = client.post(
            "/api/tickets",
            json={
                "title": "Test ticket",
                "description": "Testing",
                "category": "api_access",
                "priority": "medium",
                "requester_email": "test@example.com",
                "tags": ["test"]
            },
            headers={"Authorization": "Bearer mock-api-key-12345"}
        )
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["success"] is True
        assert data["ticket_id"].startswith("TICK-")

    def test_unauthorized_request(self):
        from mock_api.ticket_api import app
        client = app.test_client()
        resp = client.post("/api/tickets", json={"title": "x"})
        assert resp.status_code == 401
