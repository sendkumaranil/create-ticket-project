# 🎫 MCP Ticket System

[![CI](https://github.com/sendkumaranil/mcp-ticket-system/actions/workflows/ci.yml/badge.svg)](https://github.com/sendkumaranil/mcp-ticket-system/actions)
[![Python](https://img.shields.io/badge/python-3.8%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A **complete end-to-end Python implementation** of the [Model Context Protocol (MCP)](https://modelcontextprotocol.io/) integrated with an AI agent pipeline for automated ticket creation.

When a user types a natural-language message like:

> *"Dear team, I want to onboard a new API and sign-up form so that I can get access to the API"*

…the system automatically classifies the intent, pre-fills a ticket form, renders it in the chat window, and creates a real ticket via a REST API — all driven by MCP tools.

---

## ✨ Features

- **MCP Server** — JSON-RPC 2.0 over TCP with 3 tools: `render_ticket_form`, `submit_ticket`, `get_ticket_status`
- **AI Agent Pipeline** — `SupervisorAgent` classifies intent + delegates; `CreateTicketAgent` drives the MCP workflow
- **MCP UI Rendering** — server returns a JSON UI schema; client renders it as an interactive form
- **Mock Ticket REST API** — Flask API simulating Jira/ServiceNow with Bearer token auth
- **LLM-ready** — swap the NLP stub with a real Claude API call in one function
- **Fully offline** — runs with zero external dependencies beyond Flask
- **Test suite** — pytest unit tests covering agents, MCP tools, and API

---

## Architecture

```
+--------------------------------------------------------------+
|                  Chat Window  (Python CLI)                   |
|              client/chat_window.py                           |
+-------------------------+------------------------------------+
                          |  user message
                          v
+--------------------------------------------------------------+
|                   SupervisorAgent                            |
|  - Classifies intent (NLP stub / Claude API)                 |
|  - Extracts slots: category, priority, tags, email           |
|  - Delegates to CreateTicketAgent                            |
+-------------------------+------------------------------------+
                          |  intent=create_ticket, slots={...}
                          v
+--------------------------------------------------------------+
|                  CreateTicketAgent                           |
|  - Calls MCP tool: render_ticket_form (pre-fills from slots) |
|  - Returns JSON UI schema  ->  chat renders the form         |
|  - User fills & confirms                                     |
|  - Calls MCP tool: submit_ticket with form payload           |
+-------------------------+------------------------------------+
                          |  JSON-RPC 2.0 over TCP :9000
                          v
+--------------------------------------------------------------+
|              MCP Server  (port 9000)                         |
|  render_ticket_form | submit_ticket | get_ticket_status      |
|  validates payload  -  builds UI schema  -  calls REST API   |
+-------------------------+------------------------------------+
                          |  HTTP POST  Bearer token  :8080
                          v
+--------------------------------------------------------------+
|              Mock Ticket API  (port 8080)                    |
|  POST /api/tickets  ->  TICK-XXXXXXXX  status=open           |
+--------------------------------------------------------------+
```

---

## Project Structure

```
mcp-ticket-system/
├── main.py                      # Entry point — starts all services & chat loop
├── config.py                    # Centralised config (ports, API keys, env vars)
├── requirements.txt
├── setup.py
├── LICENSE
│
├── mock_api/
│   └── ticket_api.py            # Flask REST API (simulates Jira / ServiceNow)
│
├── mcp_server/
│   └── server.py                # MCP Server — JSON-RPC dispatcher, UI builder
│
├── agents/
│   └── agents.py                # SupervisorAgent, CreateTicketAgent, MCPClient
│
├── client/
│   └── chat_window.py           # Terminal chat UI + form renderer
│
├── tests/
│   └── test_intent.py           # pytest unit tests
│
└── .github/
    └── workflows/
        └── ci.yml               # GitHub Actions CI (Python 3.9-3.12)
```

---

## Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/sendkumaranil/mcp-ticket-system.git
cd mcp-ticket-system
```

### 2. Create a virtual environment

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run

```bash
python main.py
```

### 5. Try it

```
You: dear team I want to onboard new API and sign up form so that I can get access of API
```

The system will:
1. Classify intent → `create_ticket` (confidence 0.98)
2. Extract slots → `category=api_access`, `tags=[api, onboarding, signup]`
3. Call MCP tool `render_ticket_form` → receive JSON UI schema
4. Render interactive terminal form with pre-filled values
5. On confirmation → call MCP tool `submit_ticket`
6. MCP server calls Ticket API → returns `TICK-XXXXXXXX`
7. Chat displays confirmation with reference number

---

## Configuration

All settings live in `config.py` and can be overridden via environment variables:

| Variable | Default | Description |
|---|---|---|
| `TICKET_API_PORT` | `8080` | Mock Ticket API port |
| `MCP_SERVER_PORT` | `9000` | MCP Server TCP port |
| `TICKET_API_KEY`  | `mock-api-key-12345` | Bearer token for Ticket API |
| `ANTHROPIC_API_KEY` | *(unset)* | Set to enable Claude-powered intent classification |
| `ANTHROPIC_MODEL` | `claude-opus-4-6` | Claude model to use |

---

## Enabling Real LLM Classification

The system ships with a deterministic NLP classifier so it runs fully offline. To upgrade to Claude-powered intent classification, set your API key:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
```

Or edit `agents/agents.py` and replace `classify_intent()` with:

```python
import anthropic, json

def classify_intent(user_query: str) -> Intent:
    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-opus-4-6",
        max_tokens=500,
        system="""Extract intent and slots from the user message.
Return ONLY valid JSON:
{
  "intent": "create_ticket" | "check_status" | "general_help",
  "confidence": 0.0-1.0,
  "slots": {
    "title": "...",
    "description": "...",
    "category": "api_access|bug|feature_request|support|general",
    "priority": "low|medium|high|critical",
    "requester_email": "...",
    "tags": ["..."]
  }
}""",
        messages=[{"role": "user", "content": user_query}]
    )
    data = json.loads(response.content[0].text)
    return Intent(data["intent"], data["confidence"], data.get("slots", {}))
```

---

## MCP Protocol Reference

### Initialization
```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05"}}
```

### List Tools
```json
{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
```

### Render Form
```json
{"method":"tools/call","params":{"name":"render_ticket_form","arguments":{"pre_filled":{...}}}}
```

### Submit Ticket
```json
{"method":"tools/call","params":{"name":"submit_ticket","arguments":{"title":"...","category":"api_access",...}}}
```

---

## Running Tests

```bash
pip install pytest
python -m pytest tests/ -v
```

---

## Extending to Production

| Feature | How to implement |
|---|---|
| Real Jira integration | Replace `call_ticket_api()` in `mcp_server/server.py` with Jira REST API |
| Real ServiceNow | Same — swap the HTTP endpoint and payload shape |
| Web UI form rendering | Return HTML from `build_ticket_form_ui()`, serve via Flask |
| Slack integration | Render form schema as Slack Block Kit interactive message |
| WebSocket MCP transport | Replace TCP socket with `websockets` library |
| Multi-turn conversation | Add `conversation_history` list to `SupervisorAgent.process()` |

---

## License

MIT © [Anil Kumar](https://github.com/sendkumaranil)
