"""Shared Pydantic models for the Virtual Assistant API."""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4

from pydantic import BaseModel, Field


# ── Enums ──────────────────────────────────────────────────────────────────────

class ResolutionStage(str, Enum):
    TEMPLATE = "template"
    LLM = "llm"
    TICKET = "ticket"


class TicketPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class TicketStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CLOSED = "closed"


class MessageRole(str, Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


# ── Chat models ────────────────────────────────────────────────────────────────

class ChatMessage(BaseModel):
    role: MessageRole
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChatRequest(BaseModel):
    session_id: str = Field(default_factory=lambda: str(uuid4()))
    message: str = Field(..., min_length=1, max_length=2000)
    user_name: Optional[str] = None
    user_email: Optional[str] = None


class ChatResponse(BaseModel):
    session_id: str
    message: str
    stage: ResolutionStage
    template_id: Optional[str] = None
    show_ticket_form: bool = False
    follow_up: Optional[str] = None
    suggestions: list[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ── Satisfaction feedback ──────────────────────────────────────────────────────

class SatisfactionFeedback(BaseModel):
    session_id: str
    message_index: int
    satisfied: bool
    stage: ResolutionStage


# ── Ticket models ──────────────────────────────────────────────────────────────

class TicketCreateRequest(BaseModel):
    session_id: str
    name: str = Field(..., min_length=1, max_length=100)
    email: str = Field(..., pattern=r"^[^@]+@[^@]+\.[^@]+$")
    subject: str = Field(..., min_length=1, max_length=200)
    description: str = Field(..., min_length=10, max_length=2000)
    priority: TicketPriority = TicketPriority.MEDIUM
    category: str = "general"


class Ticket(BaseModel):
    id: str = Field(default_factory=lambda: f"TKT-{str(uuid4())[:8].upper()}")
    session_id: str
    name: str
    email: str
    subject: str
    description: str
    priority: TicketPriority
    category: str
    status: TicketStatus = TicketStatus.OPEN
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    conversation_summary: Optional[str] = None


class TicketResponse(BaseModel):
    ticket: Ticket
    message: str


# ── Session models ─────────────────────────────────────────────────────────────

class Session(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    user_name: Optional[str] = None
    user_email: Optional[str] = None
    history: list[ChatMessage] = Field(default_factory=list)
    current_stage: ResolutionStage = ResolutionStage.TEMPLATE
    satisfaction_score: Optional[float] = None
    consecutive_unsatisfied: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_active: datetime = Field(default_factory=datetime.utcnow)
    ticket_id: Optional[str] = None
