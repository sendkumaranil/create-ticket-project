"""
AI Agent Layer
==============
SupervisorAgent   — Classifies user intent and delegates to specialist agents
CreateTicketAgent — Handles ticket creation by calling the MCP tool

In production these would call an LLM (e.g. Anthropic Claude) for intent
classification and slot extraction. Here we use a deterministic NLP stub
so the demo runs offline, but the architecture is identical.
"""

import json
import re
from dataclasses import dataclass, field
from typing import Optional

# ─────────────────────────────────────────────
# Data Models
# ─────────────────────────────────────────────

@dataclass
class Intent:
    name: str           # "create_ticket" | "check_status" | "general_help" | "unknown"
    confidence: float   # 0.0 – 1.0
    slots: dict = field(default_factory=dict)  # extracted entities

@dataclass
class AgentResponse:
    agent: str
    action: str          # "render_form" | "call_mcp_tool" | "reply" | "error"
    message: str
    data: dict = field(default_factory=dict)


# ─────────────────────────────────────────────
# Intent Classifier
# (deterministic stub — swap with LLM call in production)
# ─────────────────────────────────────────────

TICKET_KEYWORDS = [
    r"\bonboard\b", r"\baccess\b", r"\bsign.?up\b", r"\bapi\b",
    r"\bticket\b", r"\brequest\b", r"\bintegrat\b", r"\bform\b",
    r"\braise\b", r"\bopen\b.*\bissue\b", r"\bget.*access\b",
    r"\bneed.*permission\b", r"\bwant.*enable\b",
]

CATEGORY_MAP = {
    r"\bapi\b|\bonboard\b|\baccess\b|\bsign.?up\b": "api_access",
    r"\bbug\b|\berror\b|\bbroken\b|\bfail\b":        "bug",
    r"\bfeature\b|\benhancement\b|\bimprove\b":      "feature_request",
    r"\bhelp\b|\bsupport\b|\bquestion\b":            "support",
}

PRIORITY_MAP = {
    r"\burgent\b|\bcritical\b|\basap\b|\bblocking\b": "critical",
    r"\bhigh\b|\bimportant\b|\bsoon\b":               "high",
    r"\blow\b|\bwhenever\b|\bno.*rush\b":             "low",
}


def classify_intent(user_query: str) -> Intent:
    """
    Classifies user intent and extracts relevant slots.
    In production: call Claude with a system prompt for classification.
    """
    q = user_query.lower()
    score = sum(1 for pat in TICKET_KEYWORDS if re.search(pat, q))

    if score < 1:
        return Intent("general_help", 0.3, {})

    # Extract category
    category = "general"
    for pat, cat in CATEGORY_MAP.items():
        if re.search(pat, q):
            category = cat
            break

    # Extract priority
    priority = "medium"
    for pat, pri in PRIORITY_MAP.items():
        if re.search(pat, q):
            priority = pri
            break

    # Extract a title (first sentence or truncated query)
    title = re.split(r"[.!?]", user_query)[0].strip()
    if len(title) > 80:
        title = title[:77] + "..."

    # Build description from full query
    description = user_query.strip()

    # Extract email if present
    email_match = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", user_query)
    email = email_match.group(0) if email_match else ""

    # Extract possible tags
    tags = []
    if re.search(r"\bapi\b", q):        tags.append("api")
    if re.search(r"\bonboard\b", q):    tags.append("onboarding")
    if re.search(r"\bsign.?up\b", q):   tags.append("signup")
    if re.search(r"\baccess\b", q):     tags.append("access-request")

    confidence = min(0.5 + score * 0.1, 0.98)

    return Intent(
        name="create_ticket",
        confidence=confidence,
        slots={
            "title":           title,
            "description":     description,
            "category":        category,
            "priority":        priority,
            "requester_email": email,
            "tags":            tags,
        }
    )


# ─────────────────────────────────────────────
# MCP Client (used by agents to call MCP tools)
# ─────────────────────────────────────────────

class MCPClient:
    """
    Lightweight MCP client that talks to the MCP Server over TCP socket.
    Sends JSON-RPC messages and receives responses.
    """
    def __init__(self, host="127.0.0.1", port=9000):
        self.host = host
        self.port = port
        self._sock = None
        self._counter = 0
        self._buffer = b""

    def connect(self):
        import socket
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.connect((self.host, self.port))
        self._sock.settimeout(10)
        # MCP handshake
        self._send_recv({
            "jsonrpc": "2.0", "id": self._next_id(),
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "clientInfo": {"name": "agent-mcp-client", "version": "1.0"}
            }
        })
        self._send({
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
            "params": {}
        })

    def _next_id(self):
        self._counter += 1
        return self._counter

    def _send(self, msg: dict):
        payload = json.dumps(msg) + "\n"
        self._sock.sendall(payload.encode())

    def _recv(self) -> dict:
        while b"\n" not in self._buffer:
            chunk = self._sock.recv(4096)
            if not chunk:
                raise ConnectionError("MCP server closed connection")
            self._buffer += chunk
        line, self._buffer = self._buffer.split(b"\n", 1)
        return json.loads(line.strip())

    def _send_recv(self, msg: dict) -> dict:
        self._send(msg)
        return self._recv()

    def list_tools(self) -> list:
        resp = self._send_recv({
            "jsonrpc": "2.0", "id": self._next_id(),
            "method": "tools/list", "params": {}
        })
        return resp.get("result", {}).get("tools", [])

    def call_tool(self, tool_name: str, arguments: dict) -> dict:
        resp = self._send_recv({
            "jsonrpc": "2.0", "id": self._next_id(),
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments}
        })
        result = resp.get("result", {})
        content = result.get("content", [{}])
        if content and content[0].get("type") == "text":
            return json.loads(content[0]["text"])
        return result

    def disconnect(self):
        if self._sock:
            self._sock.close()


# ─────────────────────────────────────────────
# Create Ticket Agent
# ─────────────────────────────────────────────

class CreateTicketAgent:
    """
    Dedicated agent for ticket creation.
    Step 1: Call render_ticket_form → returns UI to show user
    Step 2: When user submits form → call submit_ticket → return confirmation
    """
    def __init__(self, mcp_client: MCPClient):
        self.mcp = mcp_client
        self.name = "CreateTicketAgent"

    def prepare_form(self, slots: dict) -> AgentResponse:
        """Step 1: Ask MCP server to render a pre-filled ticket form."""
        print(f"\n[{self.name}] 📋 Requesting ticket form from MCP server...")
        result = self.mcp.call_tool("render_ticket_form", {
            "pre_filled": slots
        })

        if result.get("type") == "ui_render":
            return AgentResponse(
                agent=self.name,
                action="render_form",
                message="Here's the ticket form. Please review the details and submit.",
                data=result
            )
        return AgentResponse(
            agent=self.name,
            action="error",
            message=f"Failed to prepare form: {result.get('message')}",
            data=result
        )

    def submit_ticket(self, form_data: dict) -> AgentResponse:
        """Step 2: Submit filled form data via MCP tool."""
        print(f"\n[{self.name}] 🚀 Submitting ticket via MCP tool...")
        result = self.mcp.call_tool("submit_ticket", form_data)

        if result.get("type") == "success":
            return AgentResponse(
                agent=self.name,
                action="ticket_created",
                message=result["message"],
                data={"ticket_id": result["ticket_id"], "ticket": result["ticket"]}
            )
        return AgentResponse(
            agent=self.name,
            action="error",
            message=f"Ticket submission failed: {result.get('message')}",
            data=result
        )


# ─────────────────────────────────────────────
# Supervisor Agent
# ─────────────────────────────────────────────

class SupervisorAgent:
    """
    Orchestrates the workflow:
    1. Receives user message
    2. Classifies intent
    3. Delegates to appropriate specialist agent
    4. Returns response to chat
    """
    def __init__(self, mcp_client: MCPClient):
        self.mcp = mcp_client
        self.name = "SupervisorAgent"
        self.ticket_agent = CreateTicketAgent(mcp_client)

    def process(self, user_message: str) -> AgentResponse:
        print(f"\n[{self.name}] 📨 Processing: \"{user_message[:80]}...\"")

        intent = classify_intent(user_message)
        print(f"[{self.name}] 🧠 Intent: {intent.name} (confidence={intent.confidence:.2f})")
        print(f"[{self.name}] 📦 Slots: {json.dumps(intent.slots, indent=2)}")

        if intent.name == "create_ticket":
            print(f"[{self.name}] 🔀 Delegating to CreateTicketAgent")
            response = self.ticket_agent.prepare_form(intent.slots)
            response.data["intent"] = {
                "name": intent.name,
                "confidence": intent.confidence,
            }
            return response

        # Fallback
        return AgentResponse(
            agent=self.name,
            action="reply",
            message=(
                "I can help you create support tickets, check ticket status, "
                "or answer questions about the API. What would you like to do?"
            ),
            data={}
        )
