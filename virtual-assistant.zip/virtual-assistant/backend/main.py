"""Virtual Assistant FastAPI application.

Resolution pipeline:
  1. TemplateAgent  — keyword-scored FAQ match (fast, no API cost)
  2. LLMAgent       — Claude for nuanced / unknown queries
  3. TicketAgent    — user raises a ticket via embedded UI when still unresolved
"""
from __future__ import annotations

import os
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .agents import LLMAgent, TemplateAgent, TicketAgent, TicketStore
from .models import (
    ChatRequest,
    ChatResponse,
    MessageRole,
    ResolutionStage,
    SatisfactionFeedback,
    TicketCreateRequest,
    TicketResponse,
)
from .session_manager import SessionManager

load_dotenv()

# ── Shared singletons ──────────────────────────────────────────────────────────

session_mgr = SessionManager()
template_agent = TemplateAgent(
    confidence_threshold=float(os.getenv("TEMPLATE_CONFIDENCE_THRESHOLD", "0.65"))
)
llm_agent = LLMAgent(
    max_history_turns=int(os.getenv("MAX_HISTORY_TURNS", "10"))
)
ticket_store = TicketStore()
ticket_agent = TicketAgent(ticket_store)


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🚀 Virtual Assistant API started")
    yield
    print("🛑 Virtual Assistant API shutting down")


app = FastAPI(
    title="Virtual Assistant API",
    version="1.0.0",
    description="AI-powered customer support assistant with template → LLM → ticket pipeline",
    lifespan=lifespan,
)

# ── CORS ───────────────────────────────────────────────────────────────────────

origins = os.getenv("CORS_ORIGINS", "http://localhost:5173,http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Chat endpoint ──────────────────────────────────────────────────────────────

@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    session = session_mgr.get_or_create(
        req.session_id, req.user_name, req.user_email
    )

    # Record user message
    session_mgr.add_message(req.session_id, MessageRole.USER, req.message)

    response_text: str
    stage: ResolutionStage
    template_id = None
    follow_up = None
    show_ticket_form = False
    suggestions: list[str] = []

    # ── Stage 1: Template matching ─────────────────────────────────────────────
    if session.current_stage == ResolutionStage.TEMPLATE:
        result = template_agent.get_response(req.message, session.history)
        if result:
            response_text, template_id, follow_up = result
            stage = ResolutionStage.TEMPLATE
        else:
            # Fall through to LLM
            session_mgr.advance_stage(req.session_id, ResolutionStage.LLM)
            session.current_stage = ResolutionStage.LLM

    # ── Stage 2: LLM ──────────────────────────────────────────────────────────
    if session.current_stage == ResolutionStage.LLM:
        try:
            response_text = await llm_agent.get_response(
                req.message, session.history, session.user_name
            )
            stage = ResolutionStage.LLM
            follow_up = "Did that answer your question?"
        except Exception as exc:
            print(f"LLM error: {exc}")
            response_text = (
                "I'm sorry, I'm having trouble processing that right now. "
                "Would you like to raise a support ticket so our team can help?"
            )
            stage = ResolutionStage.LLM
            show_ticket_form = True

    # Check if we should escalate to ticket stage
    if session.consecutive_unsatisfied >= 2:
        session_mgr.advance_stage(req.session_id, ResolutionStage.TICKET)
        session.current_stage = ResolutionStage.TICKET

    if session.current_stage == ResolutionStage.TICKET:
        stage = ResolutionStage.TICKET
        show_ticket_form = True
        if session.consecutive_unsatisfied >= 2:
            response_text = (
                "I'm sorry I haven't been able to resolve this for you. 😔 "
                "Let me connect you with our support team. Please fill in the form below "
                "and an agent will follow up with you shortly."
            )
        suggestions = []

    # Quick replies for fresh sessions
    if len(session.history) <= 2:
        suggestions = template_agent.get_quick_replies()

    # Record assistant response
    session_mgr.add_message(
        req.session_id,
        MessageRole.ASSISTANT,
        response_text,
        {"stage": stage.value, "template_id": template_id},
    )

    return ChatResponse(
        session_id=req.session_id,
        message=response_text,
        stage=stage,
        template_id=template_id,
        show_ticket_form=show_ticket_form,
        follow_up=follow_up,
        suggestions=suggestions,
    )


# ── Satisfaction feedback ──────────────────────────────────────────────────────

@app.post("/api/feedback")
async def feedback(fb: SatisfactionFeedback):
    if fb.satisfied:
        session_mgr.reset_unsatisfied(fb.session_id)
        session_mgr.advance_stage(fb.session_id, ResolutionStage.TEMPLATE)
        return {"status": "ok", "message": "Glad that helped!"}
    else:
        count = session_mgr.mark_unsatisfied(fb.session_id)
        session = session_mgr.get(fb.session_id)
        if session and session.current_stage == ResolutionStage.TEMPLATE:
            session_mgr.advance_stage(fb.session_id, ResolutionStage.LLM)
        next_stage = "ticket" if count >= 2 else "llm"
        return {
            "status": "ok",
            "escalate_to": next_stage,
            "show_ticket_form": count >= 2,
        }


# ── Ticket endpoints ───────────────────────────────────────────────────────────

@app.post("/api/tickets", response_model=TicketResponse)
async def create_ticket(req: TicketCreateRequest):
    session = session_mgr.get(req.session_id)
    history = session.history if session else []

    # Auto-infer priority if not explicitly set
    inferred_priority = ticket_agent.infer_priority(req.subject, req.description)
    if req.priority == req.priority.MEDIUM:  # user left default
        req.priority = inferred_priority

    summary = await llm_agent.summarize_conversation(history)
    result = ticket_agent.create_ticket(req, summary)

    session_mgr.set_ticket(req.session_id, result.ticket.id)

    # Record ticket creation in chat history
    session_mgr.add_message(
        req.session_id,
        MessageRole.ASSISTANT,
        result.message,
        {"stage": "ticket", "ticket_id": result.ticket.id},
    )

    return result


@app.get("/api/tickets/{ticket_id}")
async def get_ticket(ticket_id: str):
    ticket = ticket_store.get(ticket_id)
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket not found")
    return ticket


@app.get("/api/sessions/{session_id}/tickets")
async def get_session_tickets(session_id: str):
    return ticket_store.get_by_session(session_id)


# ── Health & admin ─────────────────────────────────────────────────────────────

@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "1.0.0"}


@app.get("/api/admin/tickets")
async def admin_tickets():
    """Simple admin view of all tickets (add auth in production)."""
    return ticket_store.all_tickets()


@app.post("/api/admin/cleanup")
async def cleanup_sessions():
    removed = session_mgr.cleanup_expired()
    return {"removed_sessions": removed}
