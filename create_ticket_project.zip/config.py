"""
Central configuration for MCP Ticket System.
Override any value via environment variables.
"""
import os

# ── Mock Ticket API ──────────────────────────
TICKET_API_HOST = os.getenv("TICKET_API_HOST", "127.0.0.1")
TICKET_API_PORT = int(os.getenv("TICKET_API_PORT", "8080"))
TICKET_API_KEY  = os.getenv("TICKET_API_KEY",  "mock-api-key-12345")
TICKET_API_BASE = f"http://{TICKET_API_HOST}:{TICKET_API_PORT}"

# ── MCP Server ───────────────────────────────
MCP_SERVER_HOST = os.getenv("MCP_SERVER_HOST", "127.0.0.1")
MCP_SERVER_PORT = int(os.getenv("MCP_SERVER_PORT", "9000"))

# ── Agent / LLM ──────────────────────────────
# Set ANTHROPIC_API_KEY to use Claude for real intent classification.
# Leave unset to use the built-in deterministic NLP classifier.
ANTHROPIC_API_KEY   = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL     = os.getenv("ANTHROPIC_MODEL", "claude-opus-4-6")

# ── Startup timeouts (seconds) ───────────────
API_STARTUP_WAIT = float(os.getenv("API_STARTUP_WAIT", "1.0"))
MCP_STARTUP_WAIT = float(os.getenv("MCP_STARTUP_WAIT", "0.5"))
