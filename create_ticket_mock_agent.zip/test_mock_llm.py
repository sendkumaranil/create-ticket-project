"""
Test Suite for MCP Ticket System
=================================
Covers:
  1. MockLLMProvider — auto scenario matching
  2. MockLLMProvider — forced scenarios
  3. MockLLMProvider — field overrides
  4. MockLLMProvider — latency simulation
  5. MockLLMProvider — failure simulation
  6. MockLLMProvider — call inspection (call_count, call_log)
  7. classify_intent  — with MockLLMProvider
  8. MCP tool handlers
  9. Mock Ticket REST API

Run with:
    pip install pytest
    python -m pytest tests/ -v

Or without pytest:
    python tests/test_mock_llm.py
"""

import sys
import os
import time
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agents.agents import (
    MockLLMProvider,
    AnthropicLLMProvider,
    classify_intent,
    Intent,
    MOCK_SCENARIOS,
    INTENT_SYSTEM_PROMPT,
)
from mcp_server.server import handle_tool_call, handle_mcp_message, MCP_TOOLS


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def run_tests(test_class):
    """Minimal test runner used when pytest is not installed."""
    obj     = test_class()
    passed  = failed = 0
    for attr in sorted(dir(test_class)):
        if not attr.startswith("test_"):
            continue
        try:
            # run setup if present
            if hasattr(obj, "setUp"):
                obj.setUp()
            getattr(obj, attr)()
            print(f"  ✅  PASS  {test_class.__name__}::{attr}")
            passed += 1
        except Exception as exc:
            print(f"  ❌  FAIL  {test_class.__name__}::{attr}")
            print(f"           {type(exc).__name__}: {exc}")
            failed += 1
    return passed, failed


# ─────────────────────────────────────────────────────────────────────────────
# 1. Auto Scenario Matching
# ─────────────────────────────────────────────────────────────────────────────

class TestMockLLMAutoScenario:
    """MockLLMProvider picks the right scenario from the message automatically."""

    def _classify(self, msg, **kwargs):
        return classify_intent(msg, provider=MockLLMProvider(**kwargs))

    def test_api_onboarding_message(self):
        intent = self._classify(
            "dear team I want to onboard new API and sign up form so I can get access"
        )
        assert intent.name == "create_ticket"
        assert intent.slots["category"] == "api_access"
        assert "api" in intent.slots["tags"]
        assert "onboarding" in intent.slots["tags"]

    def test_api_access_request(self):
        intent = self._classify("I need API access to the payments service")
        assert intent.name == "create_ticket"
        assert intent.slots["category"] == "api_access"

    def test_bug_report(self):
        intent = self._classify(
            "there is a bug in the login page, it keeps failing"
        )
        assert intent.name == "create_ticket"
        assert intent.slots["category"] == "bug"
        assert intent.slots["priority"] == "high"

    def test_critical_issue(self):
        intent = self._classify(
            "urgent issue — production is blocking all users, need fix asap"
        )
        assert intent.name == "create_ticket"
        assert intent.slots["priority"] == "critical"
        assert "critical" in intent.slots["tags"]

    def test_feature_request(self):
        intent = self._classify("can we add support for OAuth2 as a new feature?")
        assert intent.name == "create_ticket"
        assert intent.slots["category"] == "feature_request"
        assert intent.slots["priority"] == "low"

    def test_permission_request(self):
        intent = self._classify("I need access to the staging environment, please grant permission")
        assert intent.name == "create_ticket"
        assert intent.slots["category"] == "api_access"

    def test_check_status(self):
        intent = self._classify("can you check the status of ticket TICK-ABC12345?")
        assert intent.name == "check_status"
        assert intent.slots.get("ticket_id") == "TICK-ABC12345"

    def test_general_help(self):
        intent = self._classify("hello, what is the weather today?")
        assert intent.name == "general_help"
        assert intent.confidence < 0.6

    def test_email_extracted_from_message(self):
        intent = self._classify(
            "please open an API access ticket for dev@company.com"
        )
        assert intent.slots.get("requester_email") == "dev@company.com"

    def test_description_contains_original_query(self):
        msg    = "I want to onboard a new API for my project"
        intent = self._classify(msg)
        assert msg in intent.slots.get("description", "")


# ─────────────────────────────────────────────────────────────────────────────
# 2. Forced Scenarios
# ─────────────────────────────────────────────────────────────────────────────

class TestMockLLMForcedScenario:
    """scenario= kwarg overrides auto-detection — useful for deterministic tests."""

    def test_force_critical_issue(self):
        # Message looks like a normal request, but we force critical_issue
        intent = classify_intent(
            "please help me with something",
            provider=MockLLMProvider(scenario="critical_issue"),
        )
        assert intent.slots["priority"] == "critical"
        assert intent.slots["category"] == "bug"

    def test_force_feature_request(self):
        intent = classify_intent(
            "I need to report a production outage",   # would normally → critical
            provider=MockLLMProvider(scenario="feature_request"),
        )
        assert intent.slots["category"] == "feature_request"
        assert intent.slots["priority"] == "low"

    def test_force_general_help(self):
        intent = classify_intent(
            "open a ticket for API access please",    # would normally → create_ticket
            provider=MockLLMProvider(scenario="general_help"),
        )
        assert intent.name == "general_help"

    def test_all_scenario_keys_are_valid(self):
        """Every key in MOCK_SCENARIOS must produce a parseable Intent."""
        for key in MOCK_SCENARIOS:
            intent = classify_intent(
                "test message",
                provider=MockLLMProvider(scenario=key),
            )
            assert intent.name in ("create_ticket", "check_status", "general_help"), \
                f"Scenario {key!r} produced unexpected intent {intent.name!r}"


# ─────────────────────────────────────────────────────────────────────────────
# 3. Field Overrides
# ─────────────────────────────────────────────────────────────────────────────

class TestMockLLMOverrides:
    """overrides= dict lets tests patch specific response fields post-selection."""

    def test_override_priority(self):
        intent = classify_intent(
            "I want to onboard a new API",
            provider=MockLLMProvider(overrides={"slots.priority": "critical"}),
        )
        assert intent.slots["priority"] == "critical"

    def test_override_confidence(self):
        intent = classify_intent(
            "I want to onboard a new API",
            provider=MockLLMProvider(overrides={"confidence": 0.42}),
        )
        assert abs(intent.confidence - 0.42) < 0.001

    def test_override_category(self):
        intent = classify_intent(
            "I want to onboard a new API",
            provider=MockLLMProvider(overrides={"slots.category": "bug"}),
        )
        assert intent.slots["category"] == "bug"

    def test_override_multiple_fields(self):
        intent = classify_intent(
            "I want to onboard a new API",
            provider=MockLLMProvider(overrides={
                "slots.priority": "low",
                "slots.category": "support",
                "confidence":     0.55,
            }),
        )
        assert intent.slots["priority"] == "low"
        assert intent.slots["category"] == "support"
        assert abs(intent.confidence - 0.55) < 0.001

    def test_override_with_forced_scenario(self):
        # Forced scenario + override — override wins on the specific field
        intent = classify_intent(
            "anything",
            provider=MockLLMProvider(
                scenario="bug_report",
                overrides={"slots.priority": "low"},
            ),
        )
        assert intent.slots["category"] == "bug"      # from scenario
        assert intent.slots["priority"] == "low"       # from override


# ─────────────────────────────────────────────────────────────────────────────
# 4. Latency Simulation
# ─────────────────────────────────────────────────────────────────────────────

class TestMockLLMLatency:
    """latency_ms= introduces artificial delay so you can test timeouts."""

    def test_latency_applied(self):
        provider = MockLLMProvider(latency_ms=150)
        start    = time.time()
        classify_intent("open an API ticket", provider=provider)
        elapsed  = (time.time() - start) * 1000
        assert elapsed >= 140, f"Expected >=140ms, got {elapsed:.0f}ms"

    def test_zero_latency_is_fast(self):
        provider = MockLLMProvider(latency_ms=0)
        start    = time.time()
        classify_intent("open an API ticket", provider=provider)
        elapsed  = (time.time() - start) * 1000
        assert elapsed < 100, f"Expected <100ms with no latency, got {elapsed:.0f}ms"


# ─────────────────────────────────────────────────────────────────────────────
# 5. Failure Simulation
# ─────────────────────────────────────────────────────────────────────────────

class TestMockLLMFailure:
    """fail=True raises RuntimeError — tests that callers handle LLM errors."""

    def test_fail_raises_runtime_error(self):
        provider = MockLLMProvider(fail=True)
        try:
            provider.complete("sys", "user")
            assert False, "Expected RuntimeError was not raised"
        except RuntimeError as exc:
            assert "Simulated LLM failure" in str(exc)

    def test_classify_intent_fallback_on_bad_json(self):
        """If the provider returns garbage JSON, classify_intent returns general_help."""
        class GarbageProvider(LLMProvider if False else object):
            name = "GarbageProvider"
            def complete(self, *_):
                return "this is not json at all !!!"
        # Monkey-patch the abstract methods
        GarbageProvider.__abstractmethods__ = frozenset()

        from agents.agents import LLMProvider as LP
        class _GP(LP):
            @property
            def name(self): return "GarbageProvider"
            def complete(self, *_): return "not json!!!"

        intent = classify_intent("anything", provider=_GP())
        assert intent.name == "general_help"
        assert intent.confidence == 0.0


# ─────────────────────────────────────────────────────────────────────────────
# 6. Call Inspection
# ─────────────────────────────────────────────────────────────────────────────

class TestMockLLMCallInspection:
    """call_count and call_log let tests assert on how the provider was used."""

    def test_call_count_increments(self):
        provider = MockLLMProvider()
        assert provider.call_count == 0
        classify_intent("open a ticket", provider=provider)
        assert provider.call_count == 1
        classify_intent("open another ticket", provider=provider)
        assert provider.call_count == 2

    def test_call_log_records_prompts(self):
        provider = MockLLMProvider()
        msg = "I need API access for my project"
        classify_intent(msg, provider=provider)

        assert len(provider.call_log) == 1
        entry = provider.call_log[0]
        assert entry["user"] == msg
        assert "intent classification" in entry["system"].lower() or \
               "ticket" in entry["system"].lower()

    def test_call_log_records_multiple(self):
        provider = MockLLMProvider()
        msgs = ["first message", "second message about API access"]
        for m in msgs:
            classify_intent(m, provider=provider)

        assert provider.call_count == 2
        assert provider.call_log[0]["user"] == msgs[0]
        assert provider.call_log[1]["user"] == msgs[1]

    def test_last_matched_scenario_recorded(self):
        provider = MockLLMProvider()
        classify_intent("there is a bug in the login form failing", provider=provider)
        assert provider.last_matched_scenario == "bug_report"

    def test_forced_scenario_recorded(self):
        provider = MockLLMProvider(scenario="feature_request")
        classify_intent("any message", provider=provider)
        assert provider.last_matched_scenario == "feature_request"


# ─────────────────────────────────────────────────────────────────────────────
# 7. classify_intent Integration
# ─────────────────────────────────────────────────────────────────────────────

class TestClassifyIntent:

    def test_returns_intent_dataclass(self):
        intent = classify_intent("open a ticket", provider=MockLLMProvider())
        assert isinstance(intent, Intent)
        assert isinstance(intent.name, str)
        assert isinstance(intent.confidence, float)
        assert isinstance(intent.slots, dict)

    def test_confidence_in_range(self):
        for scenario in MOCK_SCENARIOS:
            intent = classify_intent("test", provider=MockLLMProvider(scenario=scenario))
            assert 0.0 <= intent.confidence <= 1.0, \
                f"Scenario {scenario!r} returned confidence {intent.confidence}"

    def test_provider_defaults_to_mock_when_no_key(self):
        # When no ANTHROPIC_API_KEY is set, get_default_provider returns MockLLMProvider
        import agents.agents as ag
        original = ag.ANTHROPIC_API_KEY
        ag.ANTHROPIC_API_KEY = ""
        try:
            provider = ag.get_default_provider()
            assert isinstance(provider, MockLLMProvider)
        finally:
            ag.ANTHROPIC_API_KEY = original


# ─────────────────────────────────────────────────────────────────────────────
# 8. MCP Tool Handlers
# ─────────────────────────────────────────────────────────────────────────────

class TestMCPTools:

    def test_tools_list_has_three_tools(self):
        assert len(MCP_TOOLS) == 3
        names = {t["name"] for t in MCP_TOOLS}
        assert names == {"render_ticket_form", "submit_ticket", "get_ticket_status"}

    def test_render_form_returns_ui_schema(self):
        result = handle_tool_call("render_ticket_form", {
            "pre_filled": {"title": "Test", "category": "api_access", "priority": "high"}
        })
        assert result["type"] == "ui_render"
        ui = result["content"]
        field_ids = {f["id"] for f in ui["fields"]}
        assert {"title", "category", "priority", "requester_email", "description"} <= field_ids

    def test_render_form_pre_fills_values(self):
        result = handle_tool_call("render_ticket_form", {
            "pre_filled": {"category": "bug", "priority": "critical"}
        })
        fields = {f["id"]: f for f in result["content"]["fields"]}
        assert fields["category"]["value"] == "bug"
        assert fields["priority"]["value"] == "critical"

    def test_submit_ticket_missing_fields_error(self):
        result = handle_tool_call("submit_ticket", {"title": "Incomplete"})
        assert result["type"] == "error"
        assert "Missing required fields" in result["message"]

    def test_unknown_tool_returns_error(self):
        result = handle_tool_call("nonexistent_tool", {})
        assert result["type"] == "error"

    def test_mcp_initialize(self):
        resp = handle_mcp_message({
            "jsonrpc": "2.0", "id": 1, "method": "initialize",
            "params": {"protocolVersion": "2024-11-05", "clientInfo": {}}
        })
        assert resp["result"]["protocolVersion"] == "2024-11-05"
        assert "tools" in resp["result"]["capabilities"]

    def test_mcp_tools_list(self):
        resp = handle_mcp_message({
            "jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}
        })
        assert len(resp["result"]["tools"]) == 3

    def test_mcp_unknown_method(self):
        resp = handle_mcp_message({
            "jsonrpc": "2.0", "id": 3, "method": "unknown/method", "params": {}
        })
        assert "error" in resp


# ─────────────────────────────────────────────────────────────────────────────
# 9. Mock Ticket REST API
# ─────────────────────────────────────────────────────────────────────────────

class TestMockTicketAPI:

    def setUp(self):
        from mock_api.ticket_api import app
        self.client = app.test_client()
        self.headers = {"Authorization": "Bearer mock-api-key-12345"}

    def test_create_ticket_success(self):
        resp = self.client.post("/api/tickets", json={
            "title": "API Access needed",
            "description": "Need access to payments API",
            "category": "api_access",
            "priority": "medium",
            "requester_email": "dev@example.com",
            "tags": ["api"],
        }, headers=self.headers)
        assert resp.status_code == 201
        data = resp.get_json()
        assert data["success"] is True
        assert data["ticket_id"].startswith("TICK-")
        assert data["ticket"]["status"] == "open"

    def test_create_ticket_unauthorized(self):
        resp = self.client.post("/api/tickets", json={"title": "x"})
        assert resp.status_code == 401

    def test_list_tickets(self):
        resp = self.client.get("/api/tickets", headers=self.headers)
        assert resp.status_code == 200
        data = resp.get_json()
        assert "tickets" in data
        assert "total" in data

    def test_get_ticket_not_found(self):
        resp = self.client.get("/api/tickets/TICK-NOTEXIST", headers=self.headers)
        assert resp.status_code == 404

    def test_flask_app_importable(self):
        from mock_api.ticket_api import app, tickets_db
        assert app is not None
        assert isinstance(tickets_db, dict)


# ─────────────────────────────────────────────────────────────────────────────
# Standalone runner (no pytest needed)
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    suites = [
        TestMockLLMAutoScenario,
        TestMockLLMForcedScenario,
        TestMockLLMOverrides,
        TestMockLLMLatency,
        TestMockLLMFailure,
        TestMockLLMCallInspection,
        TestClassifyIntent,
        TestMCPTools,
        TestMockTicketAPI,
    ]

    total_passed = total_failed = 0
    for suite in suites:
        print(f"\n{'─'*60}")
        print(f"  {suite.__name__}")
        print(f"{'─'*60}")
        p, f = run_tests(suite)
        total_passed += p
        total_failed += f

    print(f"\n{'═'*60}")
    print(f"  Results: {total_passed} passed  {total_failed} failed")
    print(f"{'═'*60}")
    sys.exit(0 if total_failed == 0 else 1)
