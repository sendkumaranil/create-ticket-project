"""LLM-based response agent using Anthropic Claude.

Used as the second-tier fallback when template matching scores below threshold.
"""
from __future__ import annotations

import os
from typing import Optional

import anthropic

from ..models import ChatMessage, MessageRole


_SYSTEM_PROMPT = """You are a friendly, helpful virtual assistant for a customer support platform.

Your role:
- Answer customer questions clearly and concisely
- Provide accurate information about the company's products, services, and policies
- Be empathetic when customers are frustrated
- Keep responses focused and actionable
- Use markdown for formatting when helpful (bullet points, bold text)

Guidelines:
- If you cannot confidently answer a question, say so and offer to escalate
- Never make up specific information (prices, dates, policies) you don't know
- Always end with a soft question like "Does that answer your question?" or "Can I help with anything else?"
- If the user seems very frustrated after 2+ messages, gently suggest raising a support ticket
- Keep responses under 200 words unless the topic requires more detail

You represent a professional support team. Be warm but professional."""


class LLMAgent:
    """Calls Claude to generate a contextual response."""

    def __init__(self, max_history_turns: int = 10):
        self.client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        self.max_history_turns = max_history_turns
        self.model = "claude-sonnet-4-20250514"

    def _build_messages(
        self, user_message: str, history: list[ChatMessage]
    ) -> list[dict]:
        """Convert session history to Anthropic messages format."""
        messages: list[dict] = []

        # Trim to recent history only
        recent = history[-(self.max_history_turns * 2):]

        for msg in recent:
            if msg.role in (MessageRole.USER, MessageRole.ASSISTANT):
                messages.append({
                    "role": msg.role.value,
                    "content": msg.content,
                })

        # Append current user message
        messages.append({"role": "user", "content": user_message})

        return messages

    async def get_response(
        self,
        user_message: str,
        history: list[ChatMessage],
        user_name: Optional[str] = None,
    ) -> str:
        """Return Claude's response as a string."""
        messages = self._build_messages(user_message, history)

        system = _SYSTEM_PROMPT
        if user_name:
            system += f"\n\nThe customer's name is {user_name}. Address them by name where natural."

        response = self.client.messages.create(
            model=self.model,
            max_tokens=512,
            system=system,
            messages=messages,
        )

        return response.content[0].text

    async def summarize_conversation(
        self, history: list[ChatMessage]
    ) -> str:
        """Produce a short summary of the conversation for ticket context."""
        if not history:
            return "No prior conversation."

        transcript = "\n".join(
            f"{m.role.value.upper()}: {m.content}" for m in history[-20:]
        )

        response = self.client.messages.create(
            model=self.model,
            max_tokens=200,
            messages=[{
                "role": "user",
                "content": (
                    f"Summarise this customer support conversation in 2–3 sentences "
                    f"for a support ticket. Include the main issue and what was tried.\n\n{transcript}"
                ),
            }],
        )

        return response.content[0].text
