"""In-memory session store with TTL-like cleanup."""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Optional

from .models import ChatMessage, MessageRole, ResolutionStage, Session


_SESSION_TTL_HOURS = 4


class SessionManager:
    def __init__(self):
        self._sessions: dict[str, Session] = {}

    def get_or_create(
        self,
        session_id: str,
        user_name: Optional[str] = None,
        user_email: Optional[str] = None,
    ) -> Session:
        if session_id not in self._sessions:
            self._sessions[session_id] = Session(
                id=session_id,
                user_name=user_name,
                user_email=user_email,
            )
        session = self._sessions[session_id]
        session.last_active = datetime.utcnow()
        # Update contact info if provided
        if user_name:
            session.user_name = user_name
        if user_email:
            session.user_email = user_email
        return session

    def add_message(self, session_id: str, role: MessageRole, content: str, metadata: dict = None) -> None:
        session = self._sessions.get(session_id)
        if session:
            session.history.append(
                ChatMessage(role=role, content=content, metadata=metadata or {})
            )
            session.last_active = datetime.utcnow()

    def mark_unsatisfied(self, session_id: str) -> int:
        """Increment unsatisfied counter and return new count."""
        session = self._sessions.get(session_id)
        if session:
            session.consecutive_unsatisfied += 1
            return session.consecutive_unsatisfied
        return 0

    def reset_unsatisfied(self, session_id: str) -> None:
        session = self._sessions.get(session_id)
        if session:
            session.consecutive_unsatisfied = 0

    def advance_stage(self, session_id: str, stage: ResolutionStage) -> None:
        session = self._sessions.get(session_id)
        if session:
            session.current_stage = stage

    def set_ticket(self, session_id: str, ticket_id: str) -> None:
        session = self._sessions.get(session_id)
        if session:
            session.ticket_id = ticket_id

    def get(self, session_id: str) -> Optional[Session]:
        return self._sessions.get(session_id)

    def cleanup_expired(self) -> int:
        cutoff = datetime.utcnow() - timedelta(hours=_SESSION_TTL_HOURS)
        expired = [sid for sid, s in self._sessions.items() if s.last_active < cutoff]
        for sid in expired:
            del self._sessions[sid]
        return len(expired)
