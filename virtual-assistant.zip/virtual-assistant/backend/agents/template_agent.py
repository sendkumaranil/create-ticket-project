"""Template-based response agent.

Matches user intent against predefined FAQ templates using keyword scoring
before falling back to the LLM.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional

from ..models import ChatMessage, MessageRole


_TEMPLATES_PATH = Path(__file__).parent.parent / "templates_data" / "faq_templates.json"


def _load_templates() -> list[dict]:
    with open(_TEMPLATES_PATH, encoding="utf-8") as f:
        return json.load(f)


_TEMPLATES: list[dict] = _load_templates()


def _normalize(text: str) -> str:
    return re.sub(r"[^\w\s]", " ", text.lower())


def _score_template(user_text: str, template: dict) -> float:
    normalized = _normalize(user_text)
    words = set(normalized.split())
    score = 0.0

    for kw in template["keywords"]:
        kw_normalized = _normalize(kw)
        if kw_normalized in normalized:
            # Phrase match is weighted more than single-word match
            phrase_weight = 1.0 + 0.15 * (len(kw_normalized.split()) - 1)
            score += phrase_weight

    # Boost for intent-aligned single words
    score += template.get("confidence_boost", 0.0)

    # Normalise by keyword count so templates with many keywords don't dominate
    if template["keywords"]:
        score = score / (len(template["keywords"]) ** 0.4)

    return score


class TemplateAgent:
    """Scores templates against the user message and returns the best match."""

    def __init__(self, confidence_threshold: float = 0.65):
        self.threshold = confidence_threshold
        self.templates = _TEMPLATES

    def match(
        self, user_message: str, history: list[ChatMessage]
    ) -> Optional[dict]:
        """Return the best matching template dict, or None if below threshold."""
        scored = [
            (t, _score_template(user_message, t)) for t in self.templates
        ]
        scored.sort(key=lambda x: x[1], reverse=True)

        best_template, best_score = scored[0]

        if best_score >= self.threshold:
            return best_template

        return None

    def get_response(
        self, user_message: str, history: list[ChatMessage]
    ) -> Optional[tuple[str, str | None, str | None]]:
        """
        Returns (response_text, template_id, follow_up) or None if no match.
        """
        template = self.match(user_message, history)
        if template is None:
            return None

        return (
            template["response"],
            template["id"],
            template.get("follow_up"),
        )

    def get_quick_replies(self) -> list[str]:
        """Return sample quick-reply suggestions shown at conversation start."""
        return [
            "Reset my password",
            "Check order status",
            "Billing question",
            "Technical issue",
            "Contact support",
        ]
