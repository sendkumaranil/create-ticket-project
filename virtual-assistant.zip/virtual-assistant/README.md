# Virtual Assistant — End-to-End

A customer support chat assistant with a **three-tier resolution pipeline**:

```
User message
    │
    ▼
[1] Template Agent  ──── keyword match ────► instant FAQ response
    │ no match / unsatisfied
    ▼
[2] LLM Agent       ──── Claude claude-sonnet-4 ────► contextual AI response
    │ unsatisfied ×2
    ▼
[3] Ticket Agent    ──── embedded form ────► support ticket created
```

---

## Project Structure

```
virtual-assistant/
├── backend/
│   ├── agents/
│   │   ├── template_agent.py   # keyword-scored FAQ matching
│   │   ├── llm_agent.py        # Anthropic Claude integration
│   │   └── ticket_agent.py     # ticket creation & storage
│   ├── templates_data/
│   │   └── faq_templates.json  # editable FAQ bank
│   ├── main.py                 # FastAPI app + all routes
│   ├── models.py               # Pydantic models
│   └── session_manager.py      # in-memory session store
├── frontend/
│   └── index.html              # single-file chat UI (no build needed)
├── tests/
│   └── test_api.py             # pytest integration tests
├── requirements.txt
├── run.py                      # uvicorn entry point
└── .env.example
```

---

## Quick Start

### 1. Clone & install

```bash
cd virtual-assistant
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure

```bash
cp .env.example .env
# Edit .env and set ANTHROPIC_API_KEY=sk-ant-...
```

### 3. Run the backend

```bash
python run.py
# API available at http://localhost:8000
# Docs at        http://localhost:8000/docs
```

### 4. Open the UI

Open `frontend/index.html` directly in your browser — no build step required.

> **Tip**: For live reload during development, use VS Code's Live Server extension
> or `python -m http.server 5173 --directory frontend`

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/chat` | Send a message, get a response |
| `POST` | `/api/feedback` | Rate a response (satisfied / not) |
| `POST` | `/api/tickets` | Create a support ticket |
| `GET`  | `/api/tickets/{id}` | Fetch a ticket by ID |
| `GET`  | `/api/sessions/{id}/tickets` | All tickets for a session |
| `GET`  | `/api/health` | Health check |
| `GET`  | `/api/admin/tickets` | All tickets (admin view) |

### Chat Request

```json
POST /api/chat
{
  "session_id": "sess_abc123",
  "message": "I forgot my password",
  "user_name": "Jane",          // optional
  "user_email": "jane@x.com"   // optional
}
```

### Chat Response

```json
{
  "session_id": "sess_abc123",
  "message": "To reset your password: ...",
  "stage": "template",           // "template" | "llm" | "ticket"
  "template_id": "t002",
  "show_ticket_form": false,
  "follow_up": "Did that help you reset your password?",
  "suggestions": []
}
```

---

## Resolution Pipeline

### Stage 1 — Template Agent
Scores each FAQ template against the user's message using keyword matching.
Configurable threshold (`TEMPLATE_CONFIDENCE_THRESHOLD=0.65`).
Fast, zero API cost.

### Stage 2 — LLM Agent
Falls through when no template matches. Calls Claude with full conversation
history. Capable of nuanced, contextual responses.

### Stage 3 — Ticket Agent
Triggered after 2× negative feedback. Embeds a ticket form directly in the chat.
On submit, summarises the conversation using the LLM and stores the ticket.

---

## Customising the FAQ Bank

Edit `backend/templates_data/faq_templates.json`:

```json
{
  "id": "t010",
  "intent": "shipping_delay",
  "keywords": ["delayed", "late", "shipping delay", "where is my package"],
  "response": "We're sorry for the delay! Shipping times may vary due to...",
  "follow_up": "Does that explain the delay?",
  "confidence_boost": 0.1
}
```

The `confidence_boost` increases the match score — useful for intents
with few keywords but high specificity.

---

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `ANTHROPIC_API_KEY` | required | Your Anthropic API key |
| `APP_HOST` | `0.0.0.0` | Bind host |
| `APP_PORT` | `8000` | Bind port |
| `CORS_ORIGINS` | `localhost:3000,5173` | Allowed UI origins |
| `MAX_HISTORY_TURNS` | `10` | Context window for LLM |
| `TEMPLATE_CONFIDENCE_THRESHOLD` | `0.65` | Match threshold (0–1) |

---

## Production Notes

- Replace the in-memory `TicketStore` and `SessionManager` with a database (SQLAlchemy + PostgreSQL)
- Add authentication to `/api/admin/tickets`
- Add rate limiting (e.g. `slowapi`) to `/api/chat`
- Serve `frontend/index.html` via FastAPI's `StaticFiles` or a CDN
- Set `CORS_ORIGINS` to your production domain only
