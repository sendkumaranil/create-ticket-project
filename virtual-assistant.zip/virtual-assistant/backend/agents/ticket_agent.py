"""Ticket management agent.

Third-tier handler: creates, stores and retrieves support tickets
when neither templates nor LLM resolve the user's issue.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from ..models import (
    Ticket,
    TicketCreateRequest,
    TicketPriority,
    TicketResponse,
    TicketStatus,
)


class TicketStore:
    """In-memory ticket store. Replace with a database in production."""

    def __init__(self):
        self._tickets: dict[str, Ticket] = {}

    def create(self, req: TicketCreateRequest, conversation_summary: str = "") -> Ticket:
        ticket = Ticket(
            session_id=req.session_id,
            name=req.name,
            email=req.email,
            subject=req.subject,
            description=req.description,
            priority=req.priority,
            category=req.category,
            conversation_summary=conversation_summary,
        )
        self._tickets[ticket.id] = ticket
        return ticket

    def get(self, ticket_id: str) -> Optional[Ticket]:
        return self._tickets.get(ticket_id)

    def get_by_session(self, session_id: str) -> list[Ticket]:
        return [t for t in self._tickets.values() if t.session_id == session_id]

    def update_status(self, ticket_id: str, status: TicketStatus) -> Optional[Ticket]:
        ticket = self._tickets.get(ticket_id)
        if ticket:
            ticket.status = status
            ticket.updated_at = datetime.utcnow()
        return ticket

    def all_tickets(self) -> list[Ticket]:
        return list(self._tickets.values())


class TicketAgent:
    """Wraps TicketStore with business-logic helpers."""

    def __init__(self, store: TicketStore):
        self.store = store

    def create_ticket(
        self, req: TicketCreateRequest, conversation_summary: str = ""
    ) -> TicketResponse:
        ticket = self.store.create(req, conversation_summary)
        msg = (
            f"✅ **Ticket #{ticket.id} created successfully!**\n\n"
            f"Our support team will review your issue and reach out to **{ticket.email}** "
            f"within **2 business hours** (priority: {ticket.priority.value}).\n\n"
            "You'll receive a confirmation email shortly. Is there anything else I can help you with?"
        )
        return TicketResponse(ticket=ticket, message=msg)

    def infer_priority(self, subject: str, description: str) -> TicketPriority:
        """Heuristic priority from keywords in subject/description."""
        text = f"{subject} {description}".lower()
        urgent_words = {"urgent", "critical", "outage", "down", "emergency", "immediately"}
        high_words = {"broken", "can't", "cannot", "failing", "error", "blocked"}
        if any(w in text for w in urgent_words):
            return TicketPriority.URGENT
        if any(w in text for w in high_words):
            return TicketPriority.HIGH
        return TicketPriority.MEDIUM
