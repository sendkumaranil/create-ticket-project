# 🎫 MCP Ticket System — End-to-End Python Implementation

A complete Model Context Protocol (MCP) implementation showing how an AI agent
chat window integrates with MCP tools to create support tickets.

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                  Chat Window  (Python CLI)                    │
│              client/chat_window.py                           │
└─────────────────────────┬────────────────────────────────────┘
                          │ "I want to onboard a new API..."
                          ▼
┌──────────────────────────────────────────────────────────────┐
│                   SupervisorAgent                            │
│  • Classifies intent via NLP (swap with LLM in production)   │
│  • Confidence score + slot extraction                        │
│  • Delegates to specialist agents                            │
└─────────────────────────┬────────────────────────────────────┘
                          │ intent=create_ticket, slots={...}
                          ▼
┌──────────────────────────────────────────────────────────────┐
│                  CreateTicketAgent                           │
│  • Calls MCP tool: render_ticket_form (pre-fills from slots) │
│  • Returns UI schema → chat renders form                     │
│  • User fills & confirms                                     │
│  • Calls MCP tool: submit_ticket with form data              │
└─────────────────────────┬────────────────────────────────────┘
                          │ JSON-RPC 2.0 over TCP socket
                          ▼
┌──────────────────────────────────────────────────────────────┐
│              MCP Server  (port 9000)                         │
│  • render_ticket_form → returns JSON UI schema               │
│  • submit_ticket → validates → calls backend API             │
│  • get_ticket_status → looks up ticket                       │
└─────────────────────────┬────────────────────────────────────┘
                          │ HTTP POST with Bearer token
                          ▼
┌──────────────────────────────────────────────────────────────┐
│              Mock Ticket API  (port 8080)                    │
│  • POST  /api/tickets       → create ticket (returns ID)     │
│  • GET   /api/tickets/:id   → get ticket details             │
│  • GET   /api/tickets       → list all tickets               │
└──────────────────────────────────────────────────────────────┘
```

## File Structure

```
mcp_ticket_system/
├── main.py                      # Entry point — run this
├── mock_api/
│   └── ticket_api.py            # Flask REST API (simulates Jira/ServiceNow)
├── mcp_server/
│   └── server.py                # MCP Server — tools, UI schema builder, JSON-RPC
├── agents/
│   └── agents.py                # SupervisorAgent, CreateTicketAgent, MCPClient
└── client/
    └── chat_window.py           # Terminal chat UI + form renderer
```

## How to Run

```bash
cd mcp_ticket_system
python3 main.py
```

**Example interaction:**
```
You: dear team I want to onboard new API and sign up form so that I can get access of API
```

The system will:
1. Classify intent → `create_ticket` (confidence 0.98)
2. Extract slots → category=api_access, tags=[api, onboarding, signup, access-request]
3. Call MCP tool `render_ticket_form` → get form UI schema
4. Render interactive terminal form with pre-filled values
5. On confirmation → call MCP tool `submit_ticket`
6. MCP server calls Ticket API → returns `TICK-XXXXXXXX`
7. Chat displays confirmation with reference number

## MCP Protocol Flow

### 1. Initialization (JSON-RPC)
```json
→ {"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05",...}}
← {"jsonrpc":"2.0","id":1,"result":{"protocolVersion":"2024-11-05","capabilities":{"tools":{}}}}
```

### 2. List Tools
```json
→ {"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
← {"result":{"tools":[{"name":"render_ticket_form",...},{"name":"submit_ticket",...}]}}
```

### 3. Render Form (returns UI schema)
```json
→ {"method":"tools/call","params":{"name":"render_ticket_form","arguments":{"pre_filled":{...}}}}
← {"result":{"content":[{"type":"text","text":"{\"ui_type\":\"form\",\"fields\":[...]}"}]}}
```

### 4. Submit Ticket (calls backend API)
```json
→ {"method":"tools/call","params":{"name":"submit_ticket","arguments":{"title":"...","category":"api_access",...}}}
← {"result":{"content":[{"type":"text","text":"{\"type\":\"success\",\"ticket_id\":\"TICK-XXXX\"}"}]}}
```

## Key Design Patterns

### MCP UI Rendering
The MCP server returns a **JSON UI schema** describing the form fields, types,
options, and validation rules. The client renders this schema as its native UI
(terminal form here; HTML form in web/Slack implementations).

```python
# MCP Server returns:
{
  "ui_type": "form",
  "title": "🎫 Create Support Ticket",
  "fields": [
    {"id": "title",    "type": "text",       "required": True},
    {"id": "category", "type": "select",     "options": [...]},
    {"id": "priority", "type": "radio_group","options": [...]},
    ...
  ],
  "submit_button": {"mcp_tool": "submit_ticket"}  # client knows which tool to call
}
```

### Replacing the NLP with an LLM
In `agents/agents.py`, replace `classify_intent()` with an Anthropic API call:

```python
import anthropic

client = anthropic.Anthropic()

def classify_intent(user_query: str) -> Intent:
    response = client.messages.create(
        model="claude-opus-4-6",
        max_tokens=500,
        system="""Extract intent and slots from the user query. 
        Return JSON: {"intent": "create_ticket"|"check_status"|"general_help", 
                      "confidence": 0.0-1.0, "slots": {...}}""",
        messages=[{"role": "user", "content": user_query}]
    )
    data = json.loads(response.content[0].text)
    return Intent(data["intent"], data["confidence"], data.get("slots", {}))
```

## Requirements

- Python 3.8+
- Flask (for mock API)
- Standard library only for MCP server, agents, and client

## Production Extensions

| Feature | How to implement |
|---------|-----------------|
| Real LLM classification | Replace `classify_intent()` with Claude API call |
| Real Jira/ServiceNow    | Replace `call_ticket_api()` with actual API endpoint |
| Web UI form rendering   | Return HTML from `build_ticket_form_ui()` and render in browser |
| Slack integration       | Use Slack Block Kit to render the form schema as interactive blocks |
| WebSocket transport     | Replace TCP socket with `websockets` library in MCP server |
| Multi-turn conversation | Add conversation history to SupervisorAgent.process() |
| Authentication          | Add OAuth/JWT to both MCP server and chat client |
