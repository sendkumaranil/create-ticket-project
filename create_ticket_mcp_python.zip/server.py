"""
MCP Server for Ticket Management
=================================
Implements the Model Context Protocol (MCP) server pattern:
- Exposes MCP tools: create_ticket, get_ticket_status
- Renders UI form data (JSON schema) that the MCP client renders as a UI
- Processes ticket submissions and calls the backend API
- Communicates via JSON-RPC over stdio or TCP socket

MCP Protocol Flow:
  1. Client calls list_tools → server returns available tool definitions
  2. Client calls call_tool("render_ticket_form", {...}) → server returns UI schema
  3. User fills form in client UI
  4. Client calls call_tool("submit_ticket", {...}) → server calls backend API
  5. Server returns result with ticket reference
"""

import json
import uuid
import socket
import threading
import sys
import os
from datetime import datetime

# Add parent dir to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from mock_api.ticket_api import tickets_db  # shared in-process for demo

# ─────────────────────────────────────────────
# Backend API Caller
# ─────────────────────────────────────────────
import urllib.request
import urllib.error

API_BASE = "http://localhost:8080"
API_KEY  = "mock-api-key-12345"

def call_ticket_api(payload: dict) -> dict:
    """Calls the Mock Ticket API to create a ticket."""
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        f"{API_BASE}/api/tickets",
        data=body,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {API_KEY}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        return {"success": False, "error": e.read().decode()}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ─────────────────────────────────────────────
# MCP Tool Definitions (returned to client)
# ─────────────────────────────────────────────

MCP_TOOLS = [
    {
        "name": "render_ticket_form",
        "description": "Renders an interactive ticket creation UI form for the user to fill in. Returns a UI schema that the client renders as a form widget.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pre_filled": {
                    "type": "object",
                    "description": "Pre-filled values extracted from user intent",
                    "properties": {
                        "title":       {"type": "string"},
                        "description": {"type": "string"},
                        "category":    {"type": "string"},
                        "priority":    {"type": "string"},
                        "tags":        {"type": "array", "items": {"type": "string"}},
                    }
                }
            },
            "required": []
        }
    },
    {
        "name": "submit_ticket",
        "description": "Submits the ticket form data to the ticketing backend API and returns a confirmation with ticket reference number.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title":           {"type": "string", "description": "Ticket title"},
                "description":     {"type": "string", "description": "Detailed description"},
                "category":        {"type": "string", "enum": ["api_access", "bug", "feature_request", "support", "general"]},
                "priority":        {"type": "string", "enum": ["low", "medium", "high", "critical"]},
                "requester_email": {"type": "string", "description": "Submitter email"},
                "tags":            {"type": "array",  "items": {"type": "string"}},
            },
            "required": ["title", "description", "category", "priority", "requester_email"]
        }
    },
    {
        "name": "get_ticket_status",
        "description": "Retrieves the current status of a ticket by its ID.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "ticket_id": {"type": "string"}
            },
            "required": ["ticket_id"]
        }
    }
]


# ─────────────────────────────────────────────
# UI Schema Builder
# ─────────────────────────────────────────────

def build_ticket_form_ui(pre_filled: dict = None) -> dict:
    """
    Returns a UI schema (think: JSON Form / JSON Schema UI) that the
    MCP client will render as an interactive HTML form in the chat window.
    """
    pf = pre_filled or {}
    return {
        "ui_type": "form",
        "title": "🎫 Create Support Ticket",
        "subtitle": "Fill in the details below and click Submit Ticket",
        "form_id": f"ticket_form_{uuid.uuid4().hex[:8]}",
        "fields": [
            {
                "id": "title",
                "type": "text",
                "label": "Ticket Title",
                "placeholder": "Brief summary of your request",
                "value": pf.get("title", ""),
                "required": True,
                "max_length": 120,
            },
            {
                "id": "description",
                "type": "textarea",
                "label": "Description",
                "placeholder": "Describe your request in detail...",
                "value": pf.get("description", ""),
                "required": True,
                "rows": 4,
            },
            {
                "id": "category",
                "type": "select",
                "label": "Category",
                "value": pf.get("category", "api_access"),
                "required": True,
                "options": [
                    {"value": "api_access",      "label": "🔑 API Access Request"},
                    {"value": "bug",             "label": "🐛 Bug Report"},
                    {"value": "feature_request", "label": "✨ Feature Request"},
                    {"value": "support",         "label": "💬 General Support"},
                    {"value": "general",         "label": "📋 Other"},
                ],
            },
            {
                "id": "priority",
                "type": "radio_group",
                "label": "Priority",
                "value": pf.get("priority", "medium"),
                "required": True,
                "options": [
                    {"value": "low",      "label": "Low",      "color": "#22c55e"},
                    {"value": "medium",   "label": "Medium",   "color": "#f59e0b"},
                    {"value": "high",     "label": "High",     "color": "#ef4444"},
                    {"value": "critical", "label": "Critical", "color": "#7c3aed"},
                ],
            },
            {
                "id": "requester_email",
                "type": "email",
                "label": "Your Email",
                "placeholder": "you@company.com",
                "value": pf.get("requester_email", ""),
                "required": True,
            },
            {
                "id": "tags",
                "type": "tags",
                "label": "Tags (optional)",
                "value": pf.get("tags", []),
                "placeholder": "Press Enter to add tag",
            },
        ],
        "submit_button": {
            "label": "Submit Ticket",
            "mcp_tool": "submit_ticket",   # client invokes this tool on submit
        },
        "cancel_button": {"label": "Cancel"},
    }


# ─────────────────────────────────────────────
# MCP Tool Handler
# ─────────────────────────────────────────────

def handle_tool_call(tool_name: str, arguments: dict) -> dict:
    """Dispatch tool calls and return results."""

    if tool_name == "render_ticket_form":
        pre_filled = arguments.get("pre_filled", {})
        ui_schema = build_ticket_form_ui(pre_filled)
        return {
            "type": "ui_render",
            "content": ui_schema,
            "message": "Please fill in the ticket form below."
        }

    elif tool_name == "submit_ticket":
        required = ["title", "description", "category", "priority", "requester_email"]
        missing = [f for f in required if not arguments.get(f)]
        if missing:
            return {
                "type": "error",
                "message": f"Missing required fields: {', '.join(missing)}"
            }

        print(f"\n[MCP Server] 📤 Calling Ticket API with payload:")
        print(json.dumps(arguments, indent=2))

        api_result = call_ticket_api(arguments)

        if api_result.get("success"):
            return {
                "type": "success",
                "ticket_id": api_result["ticket_id"],
                "ticket":    api_result["ticket"],
                "message":   (
                    f"✅ Ticket created successfully!\n"
                    f"Reference: {api_result['ticket_id']}\n"
                    f"Title: {arguments['title']}\n"
                    f"Category: {arguments['category']}\n"
                    f"Priority: {arguments['priority']}\n"
                    f"Status: Open\n"
                    f"You will receive updates at: {arguments['requester_email']}"
                )
            }
        else:
            return {
                "type": "error",
                "message": f"Failed to create ticket: {api_result.get('error', 'Unknown error')}"
            }

    elif tool_name == "get_ticket_status":
        ticket_id = arguments.get("ticket_id")
        ticket = tickets_db.get(ticket_id)
        if ticket:
            return {
                "type": "success",
                "ticket": ticket,
                "message": f"Ticket {ticket_id}: Status={ticket['status']}"
            }
        return {"type": "error", "message": f"Ticket {ticket_id} not found"}

    return {"type": "error", "message": f"Unknown tool: {tool_name}"}


# ─────────────────────────────────────────────
# JSON-RPC MCP Message Handler
# ─────────────────────────────────────────────

def handle_mcp_message(msg: dict) -> dict:
    """Handle JSON-RPC 2.0 MCP protocol messages."""
    method = msg.get("method", "")
    msg_id = msg.get("id")
    params = msg.get("params", {})

    def ok(result):
        return {"jsonrpc": "2.0", "id": msg_id, "result": result}

    def err(code, message):
        return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": code, "message": message}}

    # MCP initialization
    if method == "initialize":
        return ok({
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "ticket-mcp-server", "version": "1.0.0"}
        })

    # List available tools
    elif method == "tools/list":
        return ok({"tools": MCP_TOOLS})

    # Call a tool
    elif method == "tools/call":
        tool_name = params.get("name")
        arguments  = params.get("arguments", {})
        print(f"\n[MCP Server] 🔧 Tool called: {tool_name}")
        result = handle_tool_call(tool_name, arguments)
        return ok({
            "content": [
                {"type": "text", "text": json.dumps(result)}
            ]
        })

    elif method == "notifications/initialized":
        return None   # no response needed for notifications

    return err(-32601, f"Method not found: {method}")


# ─────────────────────────────────────────────
# TCP Socket MCP Server
# ─────────────────────────────────────────────

class MCPServer:
    """
    Simple TCP socket MCP server.
    Each message is a newline-delimited JSON-RPC object.
    """
    def __init__(self, host="127.0.0.1", port=9000):
        self.host = host
        self.port = port
        self._server_socket = None
        self._running = False

    def start(self):
        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_socket.bind((self.host, self.port))
        self._server_socket.listen(5)
        self._running = True
        print(f"[MCP Server] 🚀 Listening on {self.host}:{self.port}")

        while self._running:
            try:
                conn, addr = self._server_socket.accept()
                t = threading.Thread(target=self._handle_client, args=(conn,), daemon=True)
                t.start()
            except OSError:
                break

    def _handle_client(self, conn):
        print(f"[MCP Server] 🔗 Client connected")
        buffer = b""
        try:
            while True:
                data = conn.recv(4096)
                if not data:
                    break
                buffer += data
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        response = handle_mcp_message(msg)
                        if response is not None:
                            payload = json.dumps(response) + "\n"
                            conn.sendall(payload.encode())
                    except json.JSONDecodeError as e:
                        print(f"[MCP Server] ⚠️ JSON parse error: {e}")
        except Exception as e:
            print(f"[MCP Server] ❌ Client error: {e}")
        finally:
            conn.close()
            print(f"[MCP Server] 🔌 Client disconnected")

    def stop(self):
        self._running = False
        if self._server_socket:
            self._server_socket.close()


def start_server_thread(host="127.0.0.1", port=9000) -> MCPServer:
    """Start MCP server in a background thread."""
    server = MCPServer(host, port)
    t = threading.Thread(target=server.start, daemon=True)
    t.start()
    return server


if __name__ == "__main__":
    server = MCPServer()
    server.start()
