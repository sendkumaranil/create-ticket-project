"""
AI Agent Layer
==============
Architecture:
  - LLMProvider          → abstract interface (real or mock)
  - MockLLMProvider      → simulates LLM JSON responses without any API call
  - AnthropicLLMProvider → real Claude API (used when ANTHROPIC_API_KEY is set)
  - classify_intent      → calls whichever provider is active
  - SupervisorAgent      → classifies intent + delegates to specialist agents
  - CreateTicketAgent    → drives MCP tool workflow

Switching between mock and real LLM:
  - Default (no API key) : MockLLMProvider is used automatically
  - With API key         : set ANTHROPIC_API_KEY env var → AnthropicLLMProvider
  - In tests             : pass MockLLMProvider(scenario="...") to SupervisorAgent
"""

import json
import re
import sys
import os
import copy
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from config import MCP_SERVER_HOST, MCP_SERVER_PORT, ANTHROPIC_API_KEY, ANTHROPIC_MODEL
except ImportError:
    MCP_SERVER_HOST   = "127.0.0.1"
    MCP_SERVER_PORT   = 9000
    ANTHROPIC_API_KEY = ""
    ANTHROPIC_MODEL   = "claude-opus-4-6"


# ─────────────────────────────────────────────────────────────────────────────
# Data Models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class Intent:
    name: str           # "create_ticket" | "check_status" | "general_help"
    confidence: float   # 0.0 – 1.0
    slots: dict = field(default_factory=dict)

@dataclass
class AgentResponse:
    agent: str
    action: str         # "render_form" | "ticket_created" | "reply" | "error"
    message: str
    data: dict = field(default_factory=dict)


# ─────────────────────────────────────────────────────────────────────────────
# LLM Provider — Abstract Interface
# ─────────────────────────────────────────────────────────────────────────────

class LLMProvider(ABC):
    """
    Abstract base for all LLM backends.
    Implement complete() to return a raw JSON string matching the intent schema.
    """

    @abstractmethod
    def complete(self, system_prompt: str, user_message: str) -> str:
        """Call the LLM and return its raw text response."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable label shown in logs."""


# ─────────────────────────────────────────────────────────────────────────────
# Mock Scenario Library
# ─────────────────────────────────────────────────────────────────────────────
# Each scenario has:
#   trigger  - list of regex patterns matched against the lower-cased user message
#   response - JSON dict the mock LLM returns (with __PLACEHOLDER__ tokens)
#
# Placeholders resolved at call time:
#   __USER_QUERY__  → full original message
#   __EMAIL__       → first email address found in message (or "")
#   __TICKET_ID__   → first TICK-XXXX found in message (or "")

MOCK_SCENARIOS: Dict[str, dict] = {

    "api_onboarding": {
        "trigger": [r"\bonboard\b", r"\bsign.?up\b.*\bapi\b", r"\bapi\b.*\bsign.?up\b"],
        "response": {
            "intent": "create_ticket",
            "confidence": 0.97,
            "slots": {
                "title": "API Onboarding & Sign-up Form Access Request",
                "description": "__USER_QUERY__",
                "category": "api_access",
                "priority": "medium",
                "requester_email": "__EMAIL__",
                "tags": ["api", "onboarding", "signup", "access-request"],
            },
        },
    },

    "api_access": {
        "trigger": [r"\bapi\b.*\baccess\b", r"\bget.*\bapi\b", r"\brequest.*\bapi\b",
                    r"\bapi\b.*\brequest\b"],
        "response": {
            "intent": "create_ticket",
            "confidence": 0.93,
            "slots": {
                "title": "API Access Request",
                "description": "__USER_QUERY__",
                "category": "api_access",
                "priority": "medium",
                "requester_email": "__EMAIL__",
                "tags": ["api", "access-request"],
            },
        },
    },

    "bug_report": {
        "trigger": [r"\bbug\b", r"\berror\b.*\b(page|screen|form|login)\b",
                    r"\bbroken\b", r"\bnot working\b", r"\bfailing\b"],
        "response": {
            "intent": "create_ticket",
            "confidence": 0.95,
            "slots": {
                "title": "Bug Report",
                "description": "__USER_QUERY__",
                "category": "bug",
                "priority": "high",
                "requester_email": "__EMAIL__",
                "tags": ["bug", "defect"],
            },
        },
    },

    "critical_issue": {
        "trigger": [r"\bcritical\b", r"\bproduction.*down\b", r"\bdown.*production\b",
                    r"\bblocking\b", r"\burgent\b.*\bissue\b", r"\basap\b"],
        "response": {
            "intent": "create_ticket",
            "confidence": 0.99,
            "slots": {
                "title": "Critical Production Issue",
                "description": "__USER_QUERY__",
                "category": "bug",
                "priority": "critical",
                "requester_email": "__EMAIL__",
                "tags": ["critical", "production", "urgent"],
            },
        },
    },

    "feature_request": {
        "trigger": [r"\bfeature\b", r"\benhancement\b", r"\bnew.*functionality\b",
                    r"\badd.*support\b", r"\bimprove\b"],
        "response": {
            "intent": "create_ticket",
            "confidence": 0.88,
            "slots": {
                "title": "Feature Request",
                "description": "__USER_QUERY__",
                "category": "feature_request",
                "priority": "low",
                "requester_email": "__EMAIL__",
                "tags": ["feature", "enhancement"],
            },
        },
    },

    "permission_request": {
        "trigger": [r"\bpermission\b", r"\bauthoriz\b", r"\bgrant.*access\b",
                    r"\benable.*access\b", r"\bneed.*access\b"],
        "response": {
            "intent": "create_ticket",
            "confidence": 0.91,
            "slots": {
                "title": "Permission / Access Request",
                "description": "__USER_QUERY__",
                "category": "api_access",
                "priority": "medium",
                "requester_email": "__EMAIL__",
                "tags": ["permission", "access-request"],
            },
        },
    },

    "check_status": {
        "trigger": [r"\bstatus\b.*\bticket\b", r"\bcheck.*ticket\b",
                    r"\btrack.*ticket\b", r"tick-[a-z0-9]+"],
        "response": {
            "intent": "check_status",
            "confidence": 0.96,
            "slots": {
                "ticket_id": "__TICKET_ID__",
            },
        },
    },

    "general_help": {
        "trigger": [],      # fallback — always matches last
        "response": {
            "intent": "general_help",
            "confidence": 0.40,
            "slots": {},
        },
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Mock LLM Provider
# ─────────────────────────────────────────────────────────────────────────────

class MockLLMProvider(LLMProvider):
    """
    Simulates an LLM without any network call.

    Initialisation options
    ──────────────────────
    scenario   : str  — force a specific scenario key (e.g. "bug_report").
                        Leave None to auto-select by matching trigger patterns.
    overrides  : dict — dot-notation field overrides applied after scenario
                        resolution. E.g. {"slots.priority": "critical"} or
                        {"confidence": 0.5}.
    latency_ms : int  — artificial delay in milliseconds (latency testing).
    fail       : bool — raise RuntimeError on every call (error-handling tests).

    Inspection helpers (useful in tests)
    ─────────────────────────────────────
    provider.call_count          → number of times complete() was called
    provider.call_log            → list of {"system":..., "user":...} dicts
    provider.last_matched_scenario → scenario key chosen on the last call

    Examples
    ────────
    # Auto-select scenario (normal use):
    provider = MockLLMProvider()

    # Force scenario for a unit test:
    provider = MockLLMProvider(scenario="critical_issue")

    # Override a field after scenario selection:
    provider = MockLLMProvider(overrides={"slots.priority": "low",
                                          "confidence": 0.6})

    # Simulate slow LLM:
    provider = MockLLMProvider(latency_ms=300)

    # Simulate broken LLM:
    provider = MockLLMProvider(fail=True)
    """

    def __init__(
        self,
        scenario:   Optional[str] = None,
        overrides:  Optional[Dict[str, Any]] = None,
        latency_ms: int  = 0,
        fail:       bool = False,
    ):
        self._scenario   = scenario
        self._overrides  = overrides or {}
        self._latency_ms = latency_ms
        self._fail       = fail

        self._call_count: int  = 0
        self._call_log:   List = []
        self.last_matched_scenario: Optional[str] = None

    @property
    def name(self) -> str:
        forced = f" forced={self._scenario!r}" if self._scenario else ""
        return f"MockLLMProvider{forced}"

    @property
    def call_count(self) -> int:
        return self._call_count

    @property
    def call_log(self) -> List[dict]:
        return self._call_log

    # ── Main entry point ─────────────────────────────────────────────────────

    def complete(self, system_prompt: str, user_message: str) -> str:
        import time

        self._call_count += 1
        self._call_log.append({"system": system_prompt, "user": user_message})

        if self._latency_ms > 0:
            time.sleep(self._latency_ms / 1000)

        if self._fail:
            raise RuntimeError("[MockLLMProvider] Simulated LLM failure for testing")

        # Pick scenario
        scenario_key = self._scenario or self._match_scenario(user_message)
        self.last_matched_scenario = scenario_key

        response = copy.deepcopy(MOCK_SCENARIOS[scenario_key]["response"])
        response = self._resolve_placeholders(response, user_message)
        response = self._apply_overrides(response)

        print(f"[{self.name}] scenario={scenario_key!r}  "
              f"intent={response['intent']}  confidence={response['confidence']}")

        return json.dumps(response)

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _match_scenario(self, user_message: str) -> str:
        q = user_message.lower()
        for key, scenario in MOCK_SCENARIOS.items():
            if key == "general_help":
                continue
            for pattern in scenario["trigger"]:
                if re.search(pattern, q):
                    return key
        return "general_help"

    def _resolve_placeholders(self, response: dict, user_message: str) -> dict:
        email_match  = re.search(r"[\w.+-]+@[\w-]+\.[\w.]+", user_message)
        tid_match    = re.search(r"TICK-[A-Z0-9]+", user_message, re.IGNORECASE)

        resolved_email = email_match.group(0) if email_match else ""
        resolved_tid   = tid_match.group(0).upper() if tid_match else ""

        def _replace(obj):
            if isinstance(obj, str):
                obj = obj.replace("__USER_QUERY__", user_message.strip())
                obj = obj.replace("__EMAIL__",      resolved_email)
                obj = obj.replace("__TICKET_ID__",  resolved_tid)
                return obj
            if isinstance(obj, dict):
                return {k: _replace(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_replace(i) for i in obj]
            return obj

        return _replace(response)

    def _apply_overrides(self, response: dict) -> dict:
        """Apply dot-notation overrides, e.g. {"slots.priority": "critical"}."""
        for dotted_key, value in self._overrides.items():
            parts  = dotted_key.split(".")
            target = response
            for part in parts[:-1]:
                target = target.setdefault(part, {})
            target[parts[-1]] = value
        return response


# ─────────────────────────────────────────────────────────────────────────────
# Real Anthropic LLM Provider
# ─────────────────────────────────────────────────────────────────────────────

class AnthropicLLMProvider(LLMProvider):
    """
    Calls the real Claude API (no SDK needed — uses urllib).
    Auto-activated when ANTHROPIC_API_KEY is present in config/env.
    """

    def __init__(self, api_key: str = ANTHROPIC_API_KEY, model: str = ANTHROPIC_MODEL):
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY is required for AnthropicLLMProvider")
        self._api_key = api_key
        self._model   = model

    @property
    def name(self) -> str:
        return f"AnthropicLLMProvider(model={self._model})"

    def complete(self, system_prompt: str, user_message: str) -> str:
        import urllib.request

        payload = json.dumps({
            "model":      self._model,
            "max_tokens": 512,
            "system":     system_prompt,
            "messages":   [{"role": "user", "content": user_message}],
        }).encode()

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "Content-Type":      "application/json",
                "x-api-key":         self._api_key,
                "anthropic-version": "2023-06-01",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
        return data["content"][0]["text"]


# ─────────────────────────────────────────────────────────────────────────────
# Provider Factory
# ─────────────────────────────────────────────────────────────────────────────

def get_default_provider() -> LLMProvider:
    """
    Auto-selects provider:
      ANTHROPIC_API_KEY set  →  AnthropicLLMProvider (real Claude)
      Not set                →  MockLLMProvider (fully offline)
    """
    if ANTHROPIC_API_KEY:
        print("[LLM] ANTHROPIC_API_KEY detected — using AnthropicLLMProvider")
        return AnthropicLLMProvider()
    print("[LLM] No API key — using MockLLMProvider (offline mode)")
    return MockLLMProvider()


# ─────────────────────────────────────────────────────────────────────────────
# Intent Classifier (provider-agnostic)
# ─────────────────────────────────────────────────────────────────────────────

INTENT_SYSTEM_PROMPT = """You are an intent classification engine for a support ticket system.
Analyse the user message and return ONLY valid JSON — no markdown, no explanation.

JSON schema:
{
  "intent":     "create_ticket" | "check_status" | "general_help",
  "confidence": <float 0.0–1.0>,
  "slots": {
    "title":           "<short ticket title, max 80 chars>",
    "description":     "<full user message>",
    "category":        "api_access" | "bug" | "feature_request" | "support" | "general",
    "priority":        "low" | "medium" | "high" | "critical",
    "requester_email": "<email if present, else empty string>",
    "tags":            ["<tag>", ...]
  }
}

Rules:
- Use "create_ticket" when the user wants to raise/open/submit/request something.
- Use "check_status" when asking about an existing ticket (may contain TICK-XXXXXX).
- Use "general_help" for greetings, general questions, or unclear input.
- For check_status / general_help, slots may be empty or minimal.
"""


def classify_intent(user_query: str, provider: Optional[LLMProvider] = None) -> Intent:
    """
    Classify user intent via the given LLM provider.

    Args:
        user_query : Raw message typed by the user.
        provider   : LLMProvider instance. Defaults to get_default_provider().

    Returns:
        Intent with name, confidence, and extracted slots.
    """
    if provider is None:
        provider = get_default_provider()

    raw = provider.complete(INTENT_SYSTEM_PROMPT, user_query)

    # Tolerate accidental markdown fences from real LLMs
    raw = re.sub(r"```(?:json)?", "", raw).strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        print(f"[classify_intent] ⚠️  JSON parse error: {exc}  raw={raw[:120]!r}")
        return Intent("general_help", 0.0, {})

    return Intent(
        name=data.get("intent", "general_help"),
        confidence=float(data.get("confidence", 0.5)),
        slots=data.get("slots", {}),
    )


# ─────────────────────────────────────────────────────────────────────────────
# MCP Client
# ─────────────────────────────────────────────────────────────────────────────

class MCPClient:
    """TCP socket MCP client (JSON-RPC 2.0)."""

    def __init__(self, host: str = MCP_SERVER_HOST, port: int = MCP_SERVER_PORT):
        self.host     = host
        self.port     = port
        self._sock    = None
        self._counter = 0
        self._buffer  = b""

    def connect(self):
        import socket
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.connect((self.host, self.port))
        self._sock.settimeout(10)
        self._send_recv({
            "jsonrpc": "2.0", "id": self._next_id(),
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "clientInfo": {"name": "agent-mcp-client", "version": "1.0"},
            },
        })
        self._send({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}})

    def _next_id(self) -> int:
        self._counter += 1
        return self._counter

    def _send(self, msg: dict):
        self._sock.sendall((json.dumps(msg) + "\n").encode())

    def _recv(self) -> dict:
        while b"\n" not in self._buffer:
            chunk = self._sock.recv(4096)
            if not chunk:
                raise ConnectionError("MCP server closed connection")
            self._buffer += chunk
        line, self._buffer = self._buffer.split(b"\n", 1)
        return json.loads(line.strip())

    def _send_recv(self, msg: dict) -> dict:
        self._send(msg)
        return self._recv()

    def list_tools(self) -> list:
        resp = self._send_recv({
            "jsonrpc": "2.0", "id": self._next_id(),
            "method": "tools/list", "params": {},
        })
        return resp.get("result", {}).get("tools", [])

    def call_tool(self, tool_name: str, arguments: dict) -> dict:
        resp = self._send_recv({
            "jsonrpc": "2.0", "id": self._next_id(),
            "method": "tools/call",
            "params": {"name": tool_name, "arguments": arguments},
        })
        result  = resp.get("result", {})
        content = result.get("content", [{}])
        if content and content[0].get("type") == "text":
            return json.loads(content[0]["text"])
        return result

    def disconnect(self):
        if self._sock:
            self._sock.close()


# ─────────────────────────────────────────────────────────────────────────────
# Create Ticket Agent
# ─────────────────────────────────────────────────────────────────────────────

class CreateTicketAgent:
    def __init__(self, mcp_client: MCPClient):
        self.mcp  = mcp_client
        self.name = "CreateTicketAgent"

    def prepare_form(self, slots: dict) -> AgentResponse:
        print(f"\n[{self.name}] 📋 Requesting ticket form from MCP server...")
        result = self.mcp.call_tool("render_ticket_form", {"pre_filled": slots})
        if result.get("type") == "ui_render":
            return AgentResponse(
                agent=self.name, action="render_form",
                message="Here's the ticket form. Please review the details and submit.",
                data=result,
            )
        return AgentResponse(
            agent=self.name, action="error",
            message=f"Failed to prepare form: {result.get('message')}",
            data=result,
        )

    def submit_ticket(self, form_data: dict) -> AgentResponse:
        print(f"\n[{self.name}] 🚀 Submitting ticket via MCP tool...")
        result = self.mcp.call_tool("submit_ticket", form_data)
        if result.get("type") == "success":
            return AgentResponse(
                agent=self.name, action="ticket_created",
                message=result["message"],
                data={"ticket_id": result["ticket_id"], "ticket": result["ticket"]},
            )
        return AgentResponse(
            agent=self.name, action="error",
            message=f"Ticket submission failed: {result.get('message')}",
            data=result,
        )


# ─────────────────────────────────────────────────────────────────────────────
# Supervisor Agent
# ─────────────────────────────────────────────────────────────────────────────

class SupervisorAgent:
    """
    Orchestrator.
    Pass llm_provider to inject MockLLMProvider in tests.
    """

    def __init__(self, mcp_client: MCPClient, llm_provider: Optional[LLMProvider] = None):
        self.mcp          = mcp_client
        self.name         = "SupervisorAgent"
        self.ticket_agent = CreateTicketAgent(mcp_client)
        self.llm_provider = llm_provider or get_default_provider()

    def process(self, user_message: str) -> AgentResponse:
        print(f"\n[{self.name}] 📨 Processing: \"{user_message[:80]}\"")
        print(f"[{self.name}] 🔌 Provider  : {self.llm_provider.name}")

        intent = classify_intent(user_message, provider=self.llm_provider)
        print(f"[{self.name}] 🧠 Intent    : {intent.name}  (confidence={intent.confidence:.2f})")
        print(f"[{self.name}] 📦 Slots     : {json.dumps(intent.slots, indent=2)}")

        if intent.name == "create_ticket":
            print(f"[{self.name}] 🔀 Delegating → CreateTicketAgent")
            response = self.ticket_agent.prepare_form(intent.slots)
            response.data["intent"] = {"name": intent.name, "confidence": intent.confidence}
            return response

        if intent.name == "check_status":
            ticket_id = intent.slots.get("ticket_id", "")
            if ticket_id:
                result = self.mcp.call_tool("get_ticket_status", {"ticket_id": ticket_id})
                return AgentResponse(
                    agent=self.name, action="reply",
                    message=result.get("message", f"Checked status for {ticket_id}"),
                    data=result,
                )

        return AgentResponse(
            agent=self.name, action="reply",
            message=(
                "I can help you create support tickets, check ticket status, "
                "or answer questions about the API. What would you like to do?"
            ),
            data={},
        )
