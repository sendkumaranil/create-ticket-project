"""Integration tests for the Virtual Assistant API.

Run with:
    cd virtual-assistant
    pytest tests/ -v
"""
import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, AsyncMock

# We need to set env vars before importing the app
import os
os.environ.setdefault("ANTHROPIC_API_KEY", "test-key")

from backend.main import app

client = TestClient(app)


# ── Health ────────────────────────────────────────────────────────────────────

def test_health():
    res = client.get("/api/health")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"


# ── Template matching ─────────────────────────────────────────────────────────

def test_template_password_reset():
    res = client.post("/api/chat", json={
        "session_id": "test-sess-001",
        "message": "I forgot my password and can't login",
    })
    assert res.status_code == 200
    data = res.json()
    assert data["stage"] == "template"
    assert data["template_id"] == "t002"
    assert "password" in data["message"].lower()


def test_template_greeting():
    res = client.post("/api/chat", json={
        "session_id": "test-sess-002",
        "message": "Hello!",
    })
    assert res.status_code == 200
    data = res.json()
    assert data["stage"] == "template"
    assert data["template_id"] == "t001"


def test_template_billing():
    res = client.post("/api/chat", json={
        "session_id": "test-sess-003",
        "message": "I have a billing question about my invoice",
    })
    assert res.status_code == 200
    data = res.json()
    assert data["stage"] == "template"
    assert "billing" in data["message"].lower()


def test_suggestions_on_first_message():
    res = client.post("/api/chat", json={
        "session_id": "test-sess-suggestions",
        "message": "Hi there",
    })
    data = res.json()
    assert isinstance(data["suggestions"], list)
    assert len(data["suggestions"]) > 0


# ── LLM fallback ─────────────────────────────────────────────────────────────

def test_llm_fallback_on_unknown_query():
    """Unknown query should fall through to LLM."""
    mock_response = "I understand you're asking about quantum entanglement in washing machines. Let me help..."

    with patch("backend.agents.llm_agent.LLMAgent.get_response", new_callable=AsyncMock) as mock_llm:
        mock_llm.return_value = mock_response
        res = client.post("/api/chat", json={
            "session_id": "test-llm-001",
            "message": "How do I configure my quantum entanglement washing machine?",
        })

    assert res.status_code == 200
    data = res.json()
    assert data["stage"] == "llm"
    assert data["message"] == mock_response


# ── Feedback & escalation ─────────────────────────────────────────────────────

def test_positive_feedback():
    # First send a message to create a session
    client.post("/api/chat", json={"session_id": "test-fb-001", "message": "hi"})

    res = client.post("/api/feedback", json={
        "session_id": "test-fb-001",
        "message_index": 0,
        "satisfied": True,
        "stage": "template",
    })
    assert res.status_code == 200
    assert res.json()["status"] == "ok"


def test_negative_feedback_escalates():
    sess = "test-fb-escalate-001"
    # Create session
    client.post("/api/chat", json={"session_id": sess, "message": "hi"})

    # First negative
    res1 = client.post("/api/feedback", json={
        "session_id": sess, "message_index": 0,
        "satisfied": False, "stage": "template",
    })
    assert res1.json()["escalate_to"] == "llm"

    # Second negative triggers ticket
    res2 = client.post("/api/feedback", json={
        "session_id": sess, "message_index": 1,
        "satisfied": False, "stage": "llm",
    })
    assert res2.json()["show_ticket_form"] is True


# ── Ticket creation ───────────────────────────────────────────────────────────

def test_create_ticket():
    with patch("backend.agents.llm_agent.LLMAgent.summarize_conversation", new_callable=AsyncMock) as mock_sum:
        mock_sum.return_value = "User had billing issue."
        res = client.post("/api/tickets", json={
            "session_id": "test-ticket-001",
            "name": "Jane Doe",
            "email": "jane@example.com",
            "subject": "Cannot access account",
            "description": "I have been locked out of my account for 3 days and need urgent help.",
            "priority": "high",
            "category": "account",
        })

    assert res.status_code == 200
    data = res.json()
    assert "ticket" in data
    assert data["ticket"]["status"] == "open"
    assert data["ticket"]["email"] == "jane@example.com"
    assert data["ticket"]["id"].startswith("TKT-")


def test_get_ticket():
    with patch("backend.agents.llm_agent.LLMAgent.summarize_conversation", new_callable=AsyncMock) as mock_sum:
        mock_sum.return_value = "Summary."
        create_res = client.post("/api/tickets", json={
            "session_id": "test-get-ticket-001",
            "name": "Bob",
            "email": "bob@example.com",
            "subject": "Test ticket",
            "description": "This is a test description that is long enough.",
            "priority": "low",
            "category": "general",
        })

    ticket_id = create_res.json()["ticket"]["id"]
    res = client.get(f"/api/tickets/{ticket_id}")
    assert res.status_code == 200
    assert res.json()["id"] == ticket_id


def test_ticket_not_found():
    res = client.get("/api/tickets/TKT-DOESNOTEXIST")
    assert res.status_code == 404


# ── Input validation ──────────────────────────────────────────────────────────

def test_empty_message_rejected():
    res = client.post("/api/chat", json={
        "session_id": "test-val-001",
        "message": "",
    })
    assert res.status_code == 422


def test_invalid_email_ticket_rejected():
    res = client.post("/api/tickets", json={
        "session_id": "test-val-002",
        "name": "Test",
        "email": "not-an-email",
        "subject": "Subject",
        "description": "A long enough description here.",
        "priority": "low",
        "category": "general",
    })
    assert res.status_code == 422


# ── Admin ─────────────────────────────────────────────────────────────────────

def test_admin_tickets():
    res = client.get("/api/admin/tickets")
    assert res.status_code == 200
    assert isinstance(res.json(), list)
