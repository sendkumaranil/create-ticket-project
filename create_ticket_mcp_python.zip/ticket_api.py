"""
Mock Ticket API Server
Simulates a real ticketing backend (e.g. Jira, ServiceNow)
Runs on http://localhost:8080
"""

import json
import uuid
import threading
from datetime import datetime
from flask import Flask, request, jsonify

app = Flask(__name__)
tickets_db = {}

API_KEY = "mock-api-key-12345"

def require_auth(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if auth != f"Bearer {API_KEY}":
            return jsonify({"error": "Unauthorized"}), 401
        return f(*args, **kwargs)
    return decorated

@app.route("/api/tickets", methods=["POST"])
@require_auth
def create_ticket():
    data = request.json
    ticket_id = f"TICK-{str(uuid.uuid4())[:8].upper()}"
    ticket = {
        "ticket_id": ticket_id,
        "title": data.get("title"),
        "description": data.get("description"),
        "priority": data.get("priority", "medium"),
        "category": data.get("category", "general"),
        "requester_email": data.get("requester_email"),
        "tags": data.get("tags", []),
        "status": "open",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
    }
    tickets_db[ticket_id] = ticket
    print(f"\n[Mock API] ✅ Ticket created: {ticket_id} — {ticket['title']}")
    return jsonify({
        "success": True,
        "ticket_id": ticket_id,
        "ticket": ticket,
        "message": f"Ticket {ticket_id} created successfully"
    }), 201

@app.route("/api/tickets/<ticket_id>", methods=["GET"])
@require_auth
def get_ticket(ticket_id):
    ticket = tickets_db.get(ticket_id)
    if not ticket:
        return jsonify({"error": "Ticket not found"}), 404
    return jsonify(ticket)

@app.route("/api/tickets", methods=["GET"])
@require_auth
def list_tickets():
    return jsonify({"tickets": list(tickets_db.values()), "total": len(tickets_db)})

def run():
    app.run(port=8080, debug=False, use_reloader=False)

if __name__ == "__main__":
    run()
